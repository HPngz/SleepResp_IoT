#include <Wire.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

#define MPU_SERVICE_UUID        "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
#define MPU_CHARACTERISTIC_UUID "12345678-1234-1234-1234-123456789abd"

#define MPU_ADDR 0x68

BLEServer* pServer = NULL;
BLECharacteristic* pCharacteristic = NULL;
bool deviceConnected = false;

// ========== 采样参数 ==========
#define SAMPLE_RATE     50
unsigned long lastSampleTime = 0;

// ========== Piezo 胸口呼吸 ==========
#define PIEZO_PIN        1
#define BASELINE_ALPHA           0.01f
#define ENVELOPE_ALPHA           0.18f
#define NOISE_ALPHA              0.01f
#define CHEST_ALPHA              0.12f
#define DELTA_ALPHA              0.25f
#define MIN_DYNAMIC_THRESHOLD    8.0f
#define BREATH_REARM_RATIO       0.55f
#define MIN_BREATH_INTERVAL_MS   1500
#define MAX_BREATH_INTERVAL_MS   10000
#define PHASE_DELTA_THRESHOLD    0.01f

float piezoBaseline = 0;
float envelope = 0;
float noiseFloor = 0;
float smoothAmplitude = 0;
bool  breathArmed = true;
float breathRate = 0;
unsigned long lastBreathTime = 0;
const byte RR_AVG_SIZE = 4;
float rrHistory[RR_AVG_SIZE] = {0};
byte rrHistIndex = 0;
byte rrValidCount = 0;
float lastChestMovement = 0;
float smoothedDelta = 0;
String breathingPhase = "Idle";

// ========== BLE发送计时 ==========
unsigned long lastBLESendTime = 0;
#define BLE_SEND_INTERVAL 500

// ========== BLE回调 ==========
class MyServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer* pServer) {
    deviceConnected = true;
    Serial.println("✅ 主机已连接");
  }
  void onDisconnect(BLEServer* pServer) {
    deviceConnected = false;
    Serial.println("❌ 主机已断开");
    pServer->startAdvertising();
  }
};

void setup() {
  Serial.begin(115200);
  Wire.begin(8, 9);
  delay(1000);

  analogReadResolution(12);
  pinMode(PIEZO_PIN, INPUT);

  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x6B);
  Wire.write(0);
  Wire.endTransmission(true);
  Serial.println("✅ MPU6050 ready");

  BLEDevice::init("chest");
  pServer = BLEDevice::createServer();
  pServer->setCallbacks(new MyServerCallbacks());

  BLEService* pService = pServer->createService(MPU_SERVICE_UUID);
  pCharacteristic = pService->createCharacteristic(
    MPU_CHARACTERISTIC_UUID,
    BLECharacteristic::PROPERTY_READ |
    BLECharacteristic::PROPERTY_NOTIFY
  );
  pCharacteristic->addDescriptor(new BLE2902());
  pService->start();

  BLEAdvertising* pAdvertising = BLEDevice::getAdvertising();
  pAdvertising->addServiceUUID(MPU_SERVICE_UUID);
  BLEDevice::startAdvertising();
  Serial.println("🔍 chest 等待 head 连接...");
}

void loop() {
  if (millis() - lastSampleTime < (1000 / SAMPLE_RATE)) return;
  lastSampleTime = millis();

  // ========== 读MPU6050 姿势 ==========
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x3B);
  Wire.endTransmission(false);
  Wire.requestFrom(MPU_ADDR, 6, true);

  int16_t ax = Wire.read() << 8 | Wire.read();
  int16_t ay = Wire.read() << 8 | Wire.read();
  int16_t az = Wire.read() << 8 | Wire.read();

  float axG = ax / 16384.0;
  float ayG = ay / 16384.0;
  float azG = az / 16384.0;

  float pitch = atan2(ayG, sqrt(axG*axG + azG*azG)) * 180.0 / PI;

  String position = "Side";
  if (abs(pitch) < 15) position = "Supine";

  // ========== 读 Piezo ==========
  int piezoRaw = analogRead(PIEZO_PIN);
  if (piezoBaseline == 0) piezoBaseline = piezoRaw;

  // 用慢速基线去掉静态偏置，再对绝对值包络做平滑。
  piezoBaseline += BASELINE_ALPHA * (piezoRaw - piezoBaseline);
  float centered = piezoRaw - piezoBaseline;
  float rectified = fabs(centered);
  envelope += ENVELOPE_ALPHA * (rectified - envelope);
  noiseFloor += NOISE_ALPHA * (envelope - noiseFloor);

  float dynamicThreshold = max(MIN_DYNAMIC_THRESHOLD, noiseFloor * 2.2f);
  float releaseThreshold = dynamicThreshold * BREATH_REARM_RATIO;
  float normalizedEnvelope = constrain(
    (envelope - noiseFloor) / max(dynamicThreshold * 3.0f, 25.0f),
    0.0f,
    1.0f
  );
  smoothAmplitude += CHEST_ALPHA * (normalizedEnvelope - smoothAmplitude);

  unsigned long now = millis();
  bool breathDetected = breathArmed &&
                        envelope > dynamicThreshold &&
                        (lastBreathTime == 0 || now - lastBreathTime >= MIN_BREATH_INTERVAL_MS);

  if (breathDetected) {
    if (lastBreathTime > 0) {
      unsigned long intervalMs = now - lastBreathTime;
      if (intervalMs <= MAX_BREATH_INTERVAL_MS) {
        float instantRR = 60000.0f / intervalMs;
        rrHistory[rrHistIndex] = instantRR;
        rrHistIndex = (rrHistIndex + 1) % RR_AVG_SIZE;
        if (rrValidCount < RR_AVG_SIZE) rrValidCount++;

        float rrSum = 0;
        for (byte i = 0; i < rrValidCount; i++) rrSum += rrHistory[i];
        breathRate = rrSum / rrValidCount;
      }
    }
    lastBreathTime = now;
    breathArmed = false;
  } else if (!breathArmed && envelope < releaseThreshold) {
    breathArmed = true;
  }

  float chestMovement = constrain(smoothAmplitude, 0.0f, 1.0f);
  float chestDelta = chestMovement - lastChestMovement;
  smoothedDelta += DELTA_ALPHA * (chestDelta - smoothedDelta);
  lastChestMovement = chestMovement;

  if (smoothedDelta > PHASE_DELTA_THRESHOLD) {
    breathingPhase = "Inhale";
  } else if (smoothedDelta < -PHASE_DELTA_THRESHOLD) {
    breathingPhase = "Exhale";
  } else if (chestMovement < 0.03f) {
    breathingPhase = "Idle";
  }

  // ========== 串口调试 ==========
  Serial.print("RR:"); Serial.print(breathRate, 1);
  Serial.print(" ");
  Serial.print("Chest:"); Serial.print(chestMovement, 3);
  Serial.print(" Delta:"); Serial.print(smoothedDelta, 3);
  Serial.print(" Env:"); Serial.print(envelope, 1);
  Serial.print(" Thr:"); Serial.print(dynamicThreshold, 1);
  Serial.print(" Phase:"); Serial.print(breathingPhase);
  Serial.print(" Pos:"); Serial.println(position);

  // ========== BLE发送 ==========
  if (millis() - lastBLESendTime >= BLE_SEND_INTERVAL && deviceConnected) {
    lastBLESendTime = millis();
    String payload = "RR:"    + String(breathRate, 1) +
                     " Chest:" + String(chestMovement, 3) +
                     " Phase:" + breathingPhase +
                     " Pos:"  + position;
    pCharacteristic->setValue(payload.c_str());
    pCharacteristic->notify();
    Serial.print("📤 发给主机: "); Serial.println(payload);
  }
}