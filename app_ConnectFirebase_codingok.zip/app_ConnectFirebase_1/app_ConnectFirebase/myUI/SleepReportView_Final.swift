import SwiftUI
import Charts

private let oneHour: TimeInterval = 3600

// MARK: - Main Report View
struct TestChartView: View {
    @ObservedObject var vm: SleepReportViewModel
    @State private var reportTab = 0
    @State private var pageTab = 0
    @State private var showStickyHeader = false

    var body: some View {
        SleepPageBackground {
            GeometryReader { proxy in
                ZStack(alignment: .top) {
                    ScrollView {
                        VStack(spacing: 14) {
                            ReportHeader(onRefresh: { vm.loadLocalCSV() }, pageTab: $pageTab)
                                .background(
                                    GeometryReader { geo in
                                        let globalMaxY = geo.frame(in: .global).maxY
                                        Color.clear
                                            .onAppear {
                                                showStickyHeader = globalMaxY < 60
                                            }
                                            .onChange(of: globalMaxY) { _, newY in
                                                withAnimation(.easeInOut(duration: 0.2)) {
                                                    showStickyHeader = newY < 60
                                                }
                                            }
                                    }
                                )
                        
                            if pageTab == 1 {
                                VStack(spacing: 16) {
                                    Image(systemName: "clock.fill")
                                        .font(.system(size: 40)).foregroundStyle(SleepTheme.blue3)
                                    Text("Sleep history coming soon")
                                        .foregroundStyle(SleepTheme.textSec)
                                }
                                .frame(maxWidth: .infinity).padding(.vertical, 60)
                                
                            } else if vm.isUploading {
                                VStack(spacing: 12) {
                                    ProgressView().tint(SleepTheme.blue5)
                                    Text("Analyzing...").font(.subheadline).foregroundStyle(SleepTheme.textSec)
                                }
                                .frame(maxWidth: .infinity).padding(.vertical, 60)
                                
                            } else if let analysis = vm.sleepAnalysis {
                                AHIHeroCard(analysis: analysis)
                                ReportTabSelector(selected: $reportTab)
                                
                                ZStack(alignment: .top) {
                                    VStack(spacing: 14) {
                                        SummarySection(analysis: analysis, records: vm.chartRecords)
                                        AISuggestionSection(analysis: analysis)
                                    }
                                    .opacity(reportTab == 0 ? 1 : 0)
                                    .allowsHitTesting(reportTab == 0)
                                    .frame(maxHeight: reportTab == 0 ? .infinity : 0)
                                    .animation(.easeInOut(duration: 0.2), value: reportTab)
                                    .clipped()
                                    
                                    CoreEventSection(
                                        analysis: analysis,
                                        records: vm.chartRecords,
                                        rawRecords: vm.rawRecords,
                                        hrPeaks: vm.hrPeaks,
                                        spo2Valleys: vm.spo2Valleys,
                                        hrAllMin: vm.hrAllMin,
                                        hrAllMax: vm.hrAllMax,
                                        spo2AllMin: vm.spo2AllMin,
                                        spo2AllMax: vm.spo2AllMax
                                    )
                                    .opacity(reportTab == 1 ? 1 : 0)
                                    .allowsHitTesting(reportTab == 1)
                                    .frame(maxHeight: reportTab == 1 ? .infinity : 0)
                                    .animation(.easeInOut(duration: 0.2), value: reportTab)
                                    .clipped()
                                    
                                    VStack(spacing: 14) {
                                        TypeJudgmentSection(analysis: analysis)
                                        PositionImpactSection(analysis: analysis)
                                    }
                                    .opacity(reportTab == 2 ? 1 : 0)
                                    .allowsHitTesting(reportTab == 2)
                                    .frame(maxHeight: reportTab == 2 ? .infinity : 0)
                                    .animation(.easeInOut(duration: 0.2), value: reportTab)
                                    .clipped()
                                }
                                
                            } else {
                                VStack(spacing: 8) {
                                    Image(systemName: "moon.zzz.fill")
                                        .font(.system(size: 40)).foregroundStyle(SleepTheme.blue3)
                                    Text("Tap the icon above to load data")
                                        .foregroundStyle(SleepTheme.textSec)
                                }
                                .frame(maxWidth: .infinity).padding(.vertical, 60)
                            }
                        }
                        .padding(.horizontal, 16)
                        .padding(.bottom, 100)
                        .padding(.top, 8)
                    }

                    if showStickyHeader {
                        collapsedHeaderBar(topInset: proxy.safeAreaInsets.top)
                            .transition(.move(edge: .top).combined(with: .opacity))
                    }
                }
                .animation(.easeInOut(duration: 0.2), value: showStickyHeader)
            }
        }
        .navigationBarHidden(true)
        .toolbar(.hidden, for: .navigationBar)
        .onAppear { if vm.sleepAnalysis == nil { vm.loadLocalCSV() } }
    }

    func collapsedHeaderBar(topInset: CGFloat) -> some View {
        VStack(spacing: 0) {
            Color.white
                .frame(height: topInset)

            HStack {
                Text("Sleep Report")
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(SleepTheme.textPri)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 12)
            .background(Color.white)
        }
        .background(Color.white)
        .overlay(alignment: .bottom) {
            Divider().opacity(0.25)
        }
        .shadow(color: SleepTheme.blue5.opacity(0.08), radius: 8, x: 0, y: 3)
        .ignoresSafeArea(edges: .top)
    }
}


// MARK: - Report Header
struct ReportHeader: View {
    let onRefresh: () -> Void
    @Binding var pageTab: Int
    @State private var spinning = false

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .center) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Sleep Report")
                        .font(.system(size: 30, weight: .bold))
                        .foregroundStyle(SleepTheme.textPri)
                    Text("Jan 23, 2025 · Last Night")
                        .font(.system(size: 14))
                        .foregroundStyle(SleepTheme.textSec)
                }
                Spacer()
                Button {
                    withAnimation(.linear(duration: 0.6)) { spinning = true }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { spinning = false }
                    onRefresh()
                } label: {
                    ZStack {
                        RoundedRectangle(cornerRadius: 14)
                            .fill(LinearGradient(colors: [SleepTheme.blue4, SleepTheme.blue5],
                                                startPoint: .topLeading, endPoint: .bottomTrailing))
                            .frame(width: 48, height: 48)
                        Image(systemName: "arrow.clockwise")
                            .font(.system(size: 20, weight: .semibold))
                            .foregroundStyle(.white)
                            .rotationEffect(.degrees(spinning ? 360 : 0))
                    }
                    .shadow(color: SleepTheme.blue5.opacity(0.3), radius: 8, x: 0, y: 4)
                }
                .buttonStyle(.plain)
            }

            HStack(spacing: 0) {
                ForEach(["Daily", "History"].indices, id: \.self) { i in
                    Button {
                        withAnimation(.spring(response: 0.3)) { pageTab = i }
                    } label: {
                        Text(["Daily", "History"][i])
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundStyle(pageTab == i ? SleepTheme.blue5 : SleepTheme.textMut)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 8)
                    }
                    .buttonStyle(.plain)
                }
            }
            .background(alignment: .bottom) {
                GeometryReader { geo in
                    let w = geo.size.width / 2
                    RoundedRectangle(cornerRadius: 2)
                        .fill(SleepTheme.blue5)
                        .frame(width: w * 0.5, height: 3)
                        .offset(x: CGFloat(pageTab) * w + w * 0.25)
                        .animation(.spring(response: 0.3), value: pageTab)
                }
                .frame(height: 3)
            }
            Divider().foregroundStyle(SleepTheme.blue2)
        }
        .padding(.top, 16)
    }
}

// MARK: - AHI Hero Card
struct AHIHeroCard: View {
    let analysis: SleepAnalysis

    var ahiColor: Color {
        switch analysis.ahiClassification {
        case "Normal":   return .green
        case "Mild":     return Color(red: 0.85, green: 0.65, blue: 0.0)
        case "Moderate": return SleepTheme.blue5
        default:         return .red
        }
    }
    
    var monitoredText: String {
        let totalSeconds = Int((analysis.totalHours * 3600).rounded())
        let hours = totalSeconds / 3600
        let minutes = (totalSeconds % 3600) / 60
        let seconds = totalSeconds % 60
        
        if hours > 0 {
            return "\(hours)h \(minutes)m monitored"
        }
        if minutes > 0 {
            return "\(minutes)m \(seconds)s monitored"
        }
        return "\(seconds)s monitored"
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Text("AHI SCORE")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(SleepTheme.textMut)
                    .kerning(0.8)
                Spacer()
                Text(monitoredText)
                    .font(.system(size: 13))
                    .foregroundStyle(SleepTheme.textSec)
            }

            HStack(alignment: .bottom, spacing: 12) {
                Text(String(format: "%.1f", analysis.ahi))
                    .font(.system(size: 68, weight: .bold, design: .rounded))
                    .foregroundStyle(SleepTheme.blue5)
                VStack(alignment: .leading, spacing: 6) {
                    Text("events / hour")
                        .font(.system(size: 16))
                        .foregroundStyle(SleepTheme.textSec)
                    HStack(spacing: 4) {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .font(.system(size: 11))
                        Text(analysis.ahiClassification)
                            .font(.system(size: 13, weight: .bold))
                    }
                    .foregroundStyle(.white)
                    .padding(.horizontal, 14).padding(.vertical, 7)
                    .background(Capsule().fill(ahiColor))
                }
                .padding(.bottom, 6)
            }

            HStack(spacing: 10) {
                ahiStatBox(value: "\(analysis.totalApnea)",                label: "Apnea")
                ahiStatBox(value: "\(analysis.totalHypopnea)",             label: "Hypopnea")
                ahiStatBox(value: "\(Int(analysis.longestEventSeconds))s", label: "Longest")
            }
        }
        .padding(20)
        .background(RoundedRectangle(cornerRadius: 20).fill(.white.opacity(0.82)))
        .overlay(RoundedRectangle(cornerRadius: 20).strokeBorder(.white, lineWidth: 1.5))
        .shadow(color: SleepTheme.blue5.opacity(0.08), radius: 12, x: 0, y: 4)
    }

    func ahiStatBox(value: String, label: String) -> some View {
        VStack(spacing: 4) {
            Text(value)
                .font(.system(size: 20, weight: .bold))
                .foregroundStyle(SleepTheme.blue5)
            Text(label)
                .font(.system(size: 11))
                .foregroundStyle(SleepTheme.textMut)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 10)
        .background(RoundedRectangle(cornerRadius: 12).fill(SleepTheme.blue1))
    }
}

// MARK: - Report Tab Selector
struct ReportTabSelector: View {
    @Binding var selected: Int
    private let tabs = ["Overview", "Events", "Others"]
    var body: some View {
        HStack(spacing: 0) {
            ForEach(tabs.indices, id: \.self) { i in
                Button {
                    selected = i
                } label: {
                    Text(tabs[i])
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(selected == i ? .white : SleepTheme.textMut)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(selected == i
                                      ? LinearGradient(colors: [SleepTheme.blue4, SleepTheme.blue5],
                                                       startPoint: .leading, endPoint: .trailing)
                                      : LinearGradient(colors: [.clear, .clear],
                                                       startPoint: .leading, endPoint: .trailing))
                        )
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
            }
        }
        .padding(4)
        .background(RoundedRectangle(cornerRadius: 16).fill(.white.opacity(0.7)))
        .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(.white, lineWidth: 1))
    }
}

// MARK: - Gauge Vital Card
struct GaugeVitalCard: View {
    struct Row { let label: String; let value: String; let color: Color }

    let title: String
    let gaugeValue: String
    let gaugeUnit: String
    let gaugeFill: Double
    let gaugeColor: Color
    let rows: [Row]

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text(title)
                .font(.system(size: 17, weight: .bold))
                .foregroundStyle(SleepTheme.textPri)

            HStack(spacing: 20) {
                ZStack {
                    Circle()
                        .stroke(SleepTheme.blue2, lineWidth: 10)
                    Circle()
                        .trim(from: 0, to: CGFloat(gaugeFill))
                        .stroke(
                            LinearGradient(colors: [SleepTheme.blue3, gaugeColor],
                                           startPoint: .leading, endPoint: .trailing),
                            style: StrokeStyle(lineWidth: 10, lineCap: .round)
                        )
                        .rotationEffect(.degrees(-90))
                    VStack(spacing: 1) {
                        Text(gaugeValue)
                            .font(.system(size: 20, weight: .bold))
                            .foregroundStyle(SleepTheme.textPri)
                        Text(gaugeUnit)
                            .font(.system(size: 9))
                            .foregroundStyle(SleepTheme.textMut)
                            .multilineTextAlignment(.center)
                    }
                }
                .frame(width: 90, height: 90)

                VStack(spacing: 10) {
                    ForEach(rows.indices, id: \.self) { i in
                        HStack {
                            Text(rows[i].label)
                                .font(.system(size: 13))
                                .foregroundStyle(SleepTheme.textMut)
                            Spacer()
                            Text(rows[i].value)
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundStyle(rows[i].color)
                        }
                    }
                }
            }
        }
        .padding(20)
        .background(RoundedRectangle(cornerRadius: 20).fill(.white.opacity(0.82)))
        .overlay(RoundedRectangle(cornerRadius: 20).strokeBorder(.white, lineWidth: 1.5))
        .shadow(color: SleepTheme.blue5.opacity(0.08), radius: 12, x: 0, y: 4)
    }
}

// MARK: - Section Card
struct SectionCard<Content: View>: View {
    let title: String
    let accentColor: Color
    let content: Content
    init(_ title: String, color: Color = SleepTheme.blue5, @ViewBuilder content: () -> Content) {
        self.title = title; self.accentColor = color; self.content = content()
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 8) {
                RoundedRectangle(cornerRadius: 2).fill(accentColor).frame(width: 3, height: 18)
                Text(title).font(.system(size: 15, weight: .bold)).foregroundStyle(SleepTheme.textPri)
            }
            content
        }
        .padding(16)
        .background(RoundedRectangle(cornerRadius: 20).fill(.white.opacity(0.82)))
        .overlay(RoundedRectangle(cornerRadius: 20).strokeBorder(.white, lineWidth: 1.5))
        .shadow(color: SleepTheme.blue5.opacity(0.07), radius: 10, x: 0, y: 3)
    }
}

// MARK: - BlueGroupBox
struct BlueGroupBox<Content: View>: View {
    let title: String; let content: Content
    init(_ title: String, @ViewBuilder content: () -> Content) {
        self.title = title; self.content = content()
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title).font(.caption).fontWeight(.semibold).foregroundStyle(SleepTheme.textMut).padding(.horizontal, 2)
            content
        }
        .padding(12)
        .background(SleepTheme.blue1)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .overlay(RoundedRectangle(cornerRadius: 12).strokeBorder(SleepTheme.blue2, lineWidth: 1))
    }
}

// MARK: - Legend
func legendItem(color: Color, label: String) -> some View {
    HStack(spacing: 4) {
        RoundedRectangle(cornerRadius: 2).fill(color).frame(width: 16, height: 6)
        Text(label).font(.caption).foregroundStyle(SleepTheme.textSec)
    }
}

// MARK: - Summary
struct SummarySection: View {
    let analysis: SleepAnalysis
    let records: [SensorRecord]
    @State private var selectedEventTime: Date? = nil

    var fullDomain: ClosedRange<Date>? {
        guard let first = analysis.events.first?.startTime,
              let last  = analysis.events.last?.endTime else { return nil }
        return (first - 1800)...(last + 1800)
    }

    var body: some View {
        SectionCard("Summary", color: SleepTheme.blue5) {
            Text(analysis.summary).font(.subheadline).foregroundStyle(SleepTheme.textSec)
                .fixedSize(horizontal: false, vertical: true)

            if !records.isEmpty, !analysis.events.isEmpty {
                Text("Breathing Events – Duration").font(.subheadline.bold()).foregroundStyle(SleepTheme.textPri)
                Text("Overview").font(.caption).foregroundStyle(SleepTheme.textMut)
                AHIOverviewChart(events: analysis.events, fullDomain: fullDomain, selectedEventTime: $selectedEventTime)
                Text("Detail (scroll)").font(.caption).foregroundStyle(SleepTheme.textMut)
                AHIDetailChart(events: analysis.events, selectedEventTime: $selectedEventTime)
                HStack(spacing: 12) {
                    legendItem(color: .red,    label: "Apnea (●)")
                    legendItem(color: .orange, label: "Hypopnea (■)")
                }
            }
        }
    }
}

// MARK: AHI Overview
struct AHIOverviewChart: View {
    let events: [SleepEvent]; let fullDomain: ClosedRange<Date>?
    @Binding var selectedEventTime: Date?
    var body: some View {
        Chart {
            ForEach(events) { event in
                let duration = event.endTime.timeIntervalSince(event.startTime)
                let isSel = selectedEventTime.map { event.startTime <= $0 && $0 <= event.endTime } ?? false
                PointMark(x: .value("Time", event.startTime), y: .value("Duration (s)", duration))
                    .foregroundStyle(event.type == .apnea ? Color.red : Color.orange)
                    .symbolSize(isSel ? 130 : 55).symbol(event.type == .apnea ? .circle : .square)
                    .opacity(isSel ? 1.0 : 0.7)
                    .annotation(position: .top) {
                        if isSel { Text(event.type == .apnea ? "A" : "H")
                            .font(.system(size: 8, weight: .bold))
                            .foregroundStyle(event.type == .apnea ? .red : .orange) }
                    }
            }
        }
        .frame(height: 110)
        .chartBackground { _ in Color(red: 0.88, green: 0.93, blue: 1.00) }
        .padding(.top, 16).padding(.trailing, 14)
        .background(RoundedRectangle(cornerRadius: 10).fill(Color(red: 0.88, green: 0.93, blue: 1.00)))
        .if(fullDomain != nil) { $0.chartXScale(domain: fullDomain!) }
        .chartXAxis { AxisMarks(values: .stride(by: .hour, count: 1)) { _ in
            AxisValueLabel(format: .dateTime.hour()).foregroundStyle(SleepTheme.textMut)
            AxisGridLine().foregroundStyle(SleepTheme.blue3.opacity(0.35)) } }
        .chartYScale(domain: -5...135)
        .chartYAxis { AxisMarks(values: [0, 60, 120]) { v in
            AxisValueLabel("\(v.as(Double.self).map { Int($0) } ?? 0)s").foregroundStyle(SleepTheme.textMut)
            AxisGridLine().foregroundStyle(SleepTheme.blue3.opacity(0.35)) } }
        .chartOverlay { proxy in GeometryReader { geo in
            Rectangle().fill(.clear).contentShape(Rectangle())
                .gesture(DragGesture(minimumDistance: 0).onEnded { v in
                    let o = geo[proxy.plotFrame!].origin
                    let loc = CGPoint(x: v.location.x - o.x, y: v.location.y - o.y)
                    if let t: Date = proxy.value(atX: loc.x),
                       let near = events.min(by: { abs($0.startTime.timeIntervalSince(t)) < abs($1.startTime.timeIntervalSince(t)) }) {
                        selectedEventTime = near.startTime }
                })
        }}
        .overlay(alignment: .topLeading) {
            Text("Tap an event to jump detail view").font(.caption2).foregroundStyle(SleepTheme.textMut).padding(4) }
    }
}

// MARK: AHI Detail
struct AHIDetailChart: View {
    let events: [SleepEvent]; @Binding var selectedEventTime: Date?
    var body: some View {
        Chart {
            ForEach(events) { event in
                let duration = event.endTime.timeIntervalSince(event.startTime)
                let isSel = selectedEventTime.map { event.startTime <= $0 && $0 <= event.endTime } ?? false
                PointMark(x: .value("Time", event.startTime), y: .value("Duration (s)", duration))
                    .foregroundStyle(event.type == .apnea ? Color.red : Color.orange)
                    .symbolSize(isSel ? 110 : 70).symbol(event.type == .apnea ? .circle : .square)
                    .annotation(position: .top) { Text(event.type == .apnea ? "A" : "H")
                        .font(.system(size: 7, weight: .bold))
                        .foregroundStyle(event.type == .apnea ? .red : .orange) }
            }
            if let t = selectedEventTime {
                RuleMark(x: .value("Selected", t)).foregroundStyle(SleepTheme.blue5.opacity(0.5))
                    .lineStyle(StrokeStyle(lineWidth: 1.5, dash: [4]))
            }
        }
        .frame(height: 160)
        .chartBackground { _ in Color(red: 0.88, green: 0.93, blue: 1.00) }
        .padding(.top, 16).padding(.trailing, 14)
        .background(RoundedRectangle(cornerRadius: 10).fill(Color(red: 0.88, green: 0.93, blue: 1.00)))
        .chartScrollableAxes(.horizontal).chartXVisibleDomain(length: oneHour)
        .chartScrollPosition(x: Binding(get: { (selectedEventTime ?? events.first?.startTime ?? Date()).addingTimeInterval(-oneHour/2) }, set: { _ in }))
        .chartXAxis { AxisMarks(values: .stride(by: .minute, count: 15)) { _ in
            AxisValueLabel(format: .dateTime.hour().minute()).foregroundStyle(SleepTheme.textMut)
            AxisGridLine().foregroundStyle(SleepTheme.blue3.opacity(0.35)) } }
        .chartYScale(domain: -5...135)
        .chartYAxis { AxisMarks(values: [0, 30, 60, 90, 120]) { v in
            AxisValueLabel("\(v.as(Double.self).map { Int($0) } ?? 0)s").foregroundStyle(SleepTheme.textMut)
            AxisGridLine().foregroundStyle(SleepTheme.blue3.opacity(0.35)) } }
    }
}

// MARK: - Core Event
struct CoreEventSection: View {
    let analysis: SleepAnalysis
    let records: [SensorRecord]
    let rawRecords: [SensorRecord]
    let hrPeaks: [HRPeak]
    let spo2Valleys: [SpO2Valley]
    let hrAllMin: Double
    let hrAllMax: Double
    let spo2AllMin: Double
    let spo2AllMax: Double
    @State private var selectedHREventTime: Date? = nil
    @State private var selectedSpO2EventTime: Date? = nil

    var fullDomain: ClosedRange<Date>? {
        guard let f = records.first?.timestamp, let l = records.last?.timestamp else { return nil }
        return f...l
    }
    var hrGaugeFill: Double {
        let span = hrAllMax - hrAllMin
        guard span > 0 else { return 0.5 }
        return min(max((analysis.avgHeartRate - hrAllMin) / span, 0.05), 0.95)
    }
    var spo2GaugeFill: Double { min(max((analysis.avgSpo2 - 80.0) / 20.0, 0.05), 0.95) }

    var body: some View {
        SectionCard("2. Core Event", color: .red) {
            VStack(alignment: .leading, spacing: 12) {
                Text("Breathing Interruption")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(SleepTheme.textMut)
                HStack(spacing: 0) {
                    interruptItem("Apnea",    "\(analysis.totalApnea)",               "events", .red)
                    Divider().frame(height: 50).opacity(0.2)
                    interruptItem("Hypopnea", "\(analysis.totalHypopnea)",            "events", .orange)
                    Divider().frame(height: 50).opacity(0.2)
                    interruptItem("Longest",  "\(Int(analysis.longestEventSeconds))", "sec",    .purple)
                }
            }
            .padding(16)
            .background(SleepTheme.blue1)
            .clipShape(RoundedRectangle(cornerRadius: 14))
            .overlay(RoundedRectangle(cornerRadius: 14).strokeBorder(SleepTheme.blue2, lineWidth: 1))

            GaugeVitalCard(
                title: "Heart Rate",
                gaugeValue: String(format: "%.0f", analysis.avgHeartRate),
                gaugeUnit: "BPM", gaugeFill: hrGaugeFill, gaugeColor: SleepTheme.blue5,
                rows: [
                    GaugeVitalCard.Row(label: "Minimum",           value: String(format: "%.0f BPM", hrAllMin),                         color: SleepTheme.textPri),
                    GaugeVitalCard.Row(label: "Maximum",           value: String(format: "%.0f BPM", hrAllMax),                         color: SleepTheme.textPri),
                    GaugeVitalCard.Row(label: "Avg Spike / Event", value: String(format: "+%.0f BPM", analysis.avgHRSpikeDuringEvents), color: Color(red: 0.85, green: 0.65, blue: 0.0))
                ]
            )

            GaugeVitalCard(
                title: "Oxygen Saturation",
                gaugeValue: String(format: "%.1f", analysis.avgSpo2),
                gaugeUnit: "SpO₂ %", gaugeFill: spo2GaugeFill, gaugeColor: SleepTheme.blue5,
                rows: [
                    GaugeVitalCard.Row(label: "Minimum",          value: String(format: "%.1f%%", spo2AllMin),                        color: SleepTheme.textPri),
                    GaugeVitalCard.Row(label: "Maximum",          value: String(format: "%.1f%%", spo2AllMax),                        color: SleepTheme.textPri),
                    GaugeVitalCard.Row(label: "Avg Drop / Event", value: String(format: "−%.1f%%", analysis.avgSpo2DropDuringEvents), color: Color(red: 0.85, green: 0.65, blue: 0.0)),
                    GaugeVitalCard.Row(label: "Longest Event",    value: "\(Int(analysis.longestEventSeconds)) sec",                  color: .red)
                ]
            )

            if !records.isEmpty {
                Text("Heart Rate").font(.subheadline.bold()).foregroundStyle(SleepTheme.textPri)
                Text("Overview").font(.caption).foregroundStyle(SleepTheme.textMut)
                HROverviewChart(records: records, events: analysis.events, hrPeaks: hrPeaks, fullDomain: fullDomain, selectedEventTime: $selectedHREventTime)
                Text("Detail (scroll)").font(.caption).foregroundStyle(SleepTheme.textMut)
                HRDetailChart(records: records, events: analysis.events, hrPeaks: hrPeaks, selectedEventTime: $selectedHREventTime)

                Text("SpO₂").font(.subheadline.bold()).foregroundStyle(SleepTheme.textPri).padding(.top, 4)
                Text("Overview").font(.caption).foregroundStyle(SleepTheme.textMut)
                SpO2OverviewChart(records: records, events: analysis.events, spo2Valleys: spo2Valleys, fullDomain: fullDomain, selectedEventTime: $selectedSpO2EventTime)
                Text("Detail (scroll)").font(.caption).foregroundStyle(SleepTheme.textMut)
                SpO2DetailChart(records: records, events: analysis.events, spo2Valleys: spo2Valleys, selectedEventTime: $selectedSpO2EventTime)

                HStack(spacing: 16) {
                    legendItem(color: SleepTheme.hrLine,   label: "HR")
                    legendItem(color: SleepTheme.spo2Line, label: "SpO₂")
                    legendItem(color: .red,                label: "Apnea")
                    legendItem(color: .orange,             label: "Hypopnea")
                }
            }
        }
    }

    func interruptItem(_ label: String, _ value: String, _ unit: String, _ color: Color) -> some View {
        VStack(spacing: 4) {
            Text(label).font(.system(size: 13)).foregroundStyle(SleepTheme.textMut)
            Text(value).font(.system(size: 28, weight: .bold)).foregroundStyle(color)
            Text(unit).font(.system(size: 12)).foregroundStyle(SleepTheme.textMut)
        }
        .frame(maxWidth: .infinity)
    }
}

// MARK: HR Overview
struct HROverviewChart: View {
    let records: [SensorRecord]; let events: [SleepEvent]; let hrPeaks: [HRPeak]
    let fullDomain: ClosedRange<Date>?; @Binding var selectedEventTime: Date?
    var hrMin: Double { (records.map { $0.heartRate }.min() ?? 40) - 5 }
    var hrMax: Double { (records.map { $0.heartRate }.max() ?? 115) + 12 }
    var barTop: Double { hrMin + (hrMax - hrMin) * 0.03 }
    var body: some View {
        Chart {
            ForEach(events) { event in
                RectangleMark(xStart: .value("S", event.startTime), xEnd: .value("E", event.endTime),
                              yStart: .value("Y0", hrMin), yEnd: .value("Y1", barTop))
                .foregroundStyle(event.type == .apnea ? Color.red : Color.orange)
                .opacity(selectedEventTime.map { event.startTime <= $0 && $0 <= event.endTime } ?? false ? 1.0 : 0.5)
            }
            ForEach(records) { r in
                LineMark(x: .value("Time", r.timestamp), y: .value("HR", r.heartRate))
                    .foregroundStyle(SleepTheme.hrLine.opacity(0.8)).lineStyle(StrokeStyle(lineWidth: 1))
                    .interpolationMethod(.catmullRom)
            }
            ForEach(hrPeaks) { p in
                PointMark(x: .value("Time", p.time), y: .value("HR", p.value))
                    .foregroundStyle(p.eventType == .apnea ? Color.red : Color.orange)
                    .symbolSize(selectedEventTime.map { abs(p.time.timeIntervalSince($0)) < oneHour } ?? false ? 60 : 25)
            }
            if let t = selectedEventTime {
                RuleMark(x: .value("S", t)).foregroundStyle(SleepTheme.blue5.opacity(0.5))
                    .lineStyle(StrokeStyle(lineWidth: 1.5, dash: [4]))
            }
        }
        .frame(height: 110)
        .chartBackground { _ in Color(red: 0.88, green: 0.93, blue: 1.00) }
        .padding(.top, 16).padding(.trailing, 14)
        .background(RoundedRectangle(cornerRadius: 10).fill(Color(red: 0.88, green: 0.93, blue: 1.00)))
        .if(fullDomain != nil) { $0.chartXScale(domain: fullDomain!) }
        .chartXAxis { AxisMarks(values: .stride(by: .hour, count: 1)) { _ in
            AxisValueLabel(format: .dateTime.hour()).foregroundStyle(SleepTheme.textMut)
            AxisGridLine().foregroundStyle(SleepTheme.blue3.opacity(0.35)) } }
        .chartYScale(domain: hrMin...hrMax)
        .chartYAxis { AxisMarks(values: .automatic(desiredCount: 4)) { v in
            AxisValueLabel("\(v.as(Double.self).map { Int($0) } ?? 0)").foregroundStyle(SleepTheme.textMut)
            AxisGridLine().foregroundStyle(SleepTheme.blue3.opacity(0.35)) } }
        .chartOverlay { proxy in GeometryReader { geo in
            Rectangle().fill(.clear).contentShape(Rectangle())
                .gesture(DragGesture(minimumDistance: 0).onEnded { v in
                    let o = geo[proxy.plotFrame!].origin
                    let loc = CGPoint(x: v.location.x - o.x, y: v.location.y - o.y)
                    if let t: Date = proxy.value(atX: loc.x),
                       let near = events.min(by: { abs($0.startTime.timeIntervalSince(t)) < abs($1.startTime.timeIntervalSince(t)) }) {
                        selectedEventTime = near.startTime }
                })
        }}
        .overlay(alignment: .topLeading) {
            Text("Tap an event to jump detail view").font(.caption2).foregroundStyle(SleepTheme.textMut).padding(4)
        }
    }
}

// MARK: HR Detail
struct HRDetailChart: View {
    let records: [SensorRecord]; let events: [SleepEvent]; let hrPeaks: [HRPeak]
    @Binding var selectedEventTime: Date?
    var hrMin: Double { (records.map { $0.heartRate }.min() ?? 40) - 5 }
    var hrMax: Double { (records.map { $0.heartRate }.max() ?? 115) + 12 }
    var barTop: Double { hrMin + (hrMax - hrMin) * 0.03 }
    var body: some View {
        Chart {
            ForEach(events) { event in
                RectangleMark(xStart: .value("S", event.startTime), xEnd: .value("E", event.endTime),
                              yStart: .value("Y0", hrMin), yEnd: .value("Y1", barTop))
                .foregroundStyle(event.type == .apnea ? Color.red : Color.orange).opacity(0.9)
            }
            ForEach(records) { r in
                LineMark(x: .value("Time", r.timestamp), y: .value("HR", r.heartRate))
                    .foregroundStyle(SleepTheme.hrLine.opacity(0.9)).lineStyle(StrokeStyle(lineWidth: 1.5))
                    .interpolationMethod(.catmullRom)
            }
            ForEach(hrPeaks) { p in
                PointMark(x: .value("Time", p.time), y: .value("HR", p.value))
                    .foregroundStyle(p.eventType == .apnea ? Color.red : Color.orange).symbolSize(40)
                    .annotation(position: .top, spacing: 2) {
                        Text("\(Int(p.value))").font(.system(size: 9, weight: .semibold))
                            .foregroundStyle(p.eventType == .apnea ? Color.red : Color.orange)
                    }
            }
            if let t = selectedEventTime {
                RuleMark(x: .value("S", t)).foregroundStyle(SleepTheme.blue5.opacity(0.6))
                    .lineStyle(StrokeStyle(lineWidth: 2, dash: [5]))
                    .annotation(position: .top, alignment: .leading) {
                        Text("◀").font(.caption2).foregroundStyle(SleepTheme.blue5)
                    }
            }
        }
        .frame(height: 150)
        .chartBackground { _ in Color(red: 0.88, green: 0.93, blue: 1.00) }
        .padding(.top, 16).padding(.trailing, 14)
        .background(RoundedRectangle(cornerRadius: 10).fill(Color(red: 0.88, green: 0.93, blue: 1.00)))
        .chartScrollableAxes(.horizontal).chartXVisibleDomain(length: oneHour)
        .chartScrollPosition(x: Binding(get: { (selectedEventTime ?? records.first?.timestamp ?? Date()).addingTimeInterval(-oneHour/2) }, set: { _ in }))
        .chartXAxis { AxisMarks(values: .stride(by: .minute, count: 15)) { _ in
            AxisValueLabel(format: .dateTime.hour().minute()).foregroundStyle(SleepTheme.textMut)
            AxisGridLine().foregroundStyle(SleepTheme.blue3.opacity(0.35)) } }
        .chartYScale(domain: hrMin...hrMax)
        .chartYAxis { AxisMarks(values: .automatic(desiredCount: 4)) { v in
            AxisValueLabel("\(v.as(Double.self).map { Int($0) } ?? 0)").foregroundStyle(SleepTheme.textMut)
            AxisGridLine().foregroundStyle(SleepTheme.blue3.opacity(0.35)) } }
    }
}

// MARK: SpO2 Overview
struct SpO2OverviewChart: View {
    let records: [SensorRecord]; let events: [SleepEvent]; let spo2Valleys: [SpO2Valley]
    let fullDomain: ClosedRange<Date>?; @Binding var selectedEventTime: Date?
    var spo2Min: Double { (records.map { $0.spo2 }.min() ?? 80) - 0.5 }
    var spo2Max: Double { (records.map { $0.spo2 }.max() ?? 100) + 2.5 }
    var barTop: Double { spo2Min + (spo2Max - spo2Min) * 0.03 }
    var body: some View {
        Chart {
            ForEach(events) { event in
                RectangleMark(xStart: .value("S", event.startTime), xEnd: .value("E", event.endTime),
                              yStart: .value("Y0", spo2Min), yEnd: .value("Y1", barTop))
                .foregroundStyle(event.type == .apnea ? Color.red : Color.orange)
                .opacity(selectedEventTime.map { event.startTime <= $0 && $0 <= event.endTime } ?? false ? 1.0 : 0.5)
            }
            ForEach(records) { r in
                LineMark(x: .value("Time", r.timestamp), y: .value("SpO₂", r.spo2))
                    .foregroundStyle(SleepTheme.spo2Line.opacity(0.8)).lineStyle(StrokeStyle(lineWidth: 1))
                    .interpolationMethod(.linear)
            }
            ForEach(spo2Valleys) { v in
                PointMark(x: .value("Time", v.time), y: .value("SpO₂", v.value))
                    .foregroundStyle(v.eventType == .apnea ? Color.red : Color.orange)
                    .symbolSize(selectedEventTime.map { abs(v.time.timeIntervalSince($0)) < oneHour } ?? false ? 60 : 25)
            }
            if let t = selectedEventTime {
                RuleMark(x: .value("S", t)).foregroundStyle(SleepTheme.blue5.opacity(0.5))
                    .lineStyle(StrokeStyle(lineWidth: 1.5, dash: [4]))
            }
        }
        .frame(height: 110)
        .chartBackground { _ in Color(red: 0.88, green: 0.93, blue: 1.00) }
        .padding(.top, 16).padding(.trailing, 14)
        .background(RoundedRectangle(cornerRadius: 10).fill(Color(red: 0.88, green: 0.93, blue: 1.00)))
        .if(fullDomain != nil) { $0.chartXScale(domain: fullDomain!) }
        .chartXAxis { AxisMarks(values: .stride(by: .hour, count: 1)) { _ in
            AxisValueLabel(format: .dateTime.hour()).foregroundStyle(SleepTheme.textMut)
            AxisGridLine().foregroundStyle(SleepTheme.blue3.opacity(0.35)) } }
        .chartYScale(domain: spo2Min...spo2Max)
        .chartYAxis { AxisMarks(values: .automatic(desiredCount: 4)) { v in
            AxisValueLabel("\(v.as(Double.self).map { Int($0) } ?? 0)%").foregroundStyle(SleepTheme.textMut)
            AxisGridLine().foregroundStyle(SleepTheme.blue3.opacity(0.35)) } }
        .chartOverlay { proxy in GeometryReader { geo in
            Rectangle().fill(.clear).contentShape(Rectangle())
                .gesture(DragGesture(minimumDistance: 0).onEnded { val in
                    let o = geo[proxy.plotFrame!].origin
                    let loc = CGPoint(x: val.location.x - o.x, y: val.location.y - o.y)
                    if let t: Date = proxy.value(atX: loc.x),
                       let near = events.min(by: { abs($0.startTime.timeIntervalSince(t)) < abs($1.startTime.timeIntervalSince(t)) }) {
                        selectedEventTime = near.startTime }
                })
        }}
        .overlay(alignment: .topLeading) {
            Text("Tap an event to jump detail view").font(.caption2).foregroundStyle(SleepTheme.textMut).padding(4)
        }
    }
}

// MARK: SpO2 Detail
struct SpO2DetailChart: View {
    let records: [SensorRecord]; let events: [SleepEvent]; let spo2Valleys: [SpO2Valley]
    @Binding var selectedEventTime: Date?
    var spo2Min: Double { (records.map { $0.spo2 }.min() ?? 80) - 0.5 }
    var spo2Max: Double { (records.map { $0.spo2 }.max() ?? 100) + 2.5 }
    var barTop: Double { spo2Min + (spo2Max - spo2Min) * 0.03 }
    var body: some View {
        Chart {
            ForEach(events) { event in
                RectangleMark(xStart: .value("S", event.startTime), xEnd: .value("E", event.endTime),
                              yStart: .value("Y0", spo2Min), yEnd: .value("Y1", barTop))
                .foregroundStyle(event.type == .apnea ? Color.red : Color.orange).opacity(0.9)
            }
            ForEach(records) { r in
                LineMark(x: .value("Time", r.timestamp), y: .value("SpO₂", r.spo2))
                    .foregroundStyle(SleepTheme.spo2Line.opacity(0.9)).lineStyle(StrokeStyle(lineWidth: 1.5))
                    .interpolationMethod(.linear)
            }
            ForEach(spo2Valleys) { v in
                PointMark(x: .value("Time", v.time), y: .value("SpO₂", v.value))
                    .foregroundStyle(v.eventType == .apnea ? Color.red : Color.orange).symbolSize(40)
                    .annotation(position: .bottom, spacing: 2) {
                        Text("\(v.value.formatted(.number.precision(.fractionLength(0...2))))%").font(.system(size: 9, weight: .semibold))
                            .foregroundStyle(v.eventType == .apnea ? Color.red : Color.orange)
                    }
            }
            if let t = selectedEventTime {
                RuleMark(x: .value("S", t)).foregroundStyle(SleepTheme.blue5.opacity(0.6))
                    .lineStyle(StrokeStyle(lineWidth: 2, dash: [5]))
            }
        }
        .frame(height: 150)
        .chartBackground { _ in Color(red: 0.88, green: 0.93, blue: 1.00) }
        .padding(.top, 16).padding(.trailing, 14)
        .background(RoundedRectangle(cornerRadius: 10).fill(Color(red: 0.88, green: 0.93, blue: 1.00)))
        .chartScrollableAxes(.horizontal).chartXVisibleDomain(length: oneHour)
        .chartScrollPosition(x: Binding(get: { (selectedEventTime ?? records.first?.timestamp ?? Date()).addingTimeInterval(-oneHour/2) }, set: { _ in }))
        .chartXAxis { AxisMarks(values: .stride(by: .minute, count: 15)) { _ in
            AxisValueLabel(format: .dateTime.hour().minute()).foregroundStyle(SleepTheme.textMut)
            AxisGridLine().foregroundStyle(SleepTheme.blue3.opacity(0.35)) } }
        .chartYScale(domain: spo2Min...spo2Max)
        .chartYAxis { AxisMarks(values: .automatic(desiredCount: 4)) { v in
            AxisValueLabel("\(v.as(Double.self).map { Int($0) } ?? 0)%").foregroundStyle(SleepTheme.textMut)
            AxisGridLine().foregroundStyle(SleepTheme.blue3.opacity(0.35)) } }
    }
}

// MARK: - View extension
extension View {
    @ViewBuilder
    func `if`<C: View>(_ cond: Bool, transform: (Self) -> C) -> some View {
        if cond { transform(self) } else { self }
    }
}

// MARK: - Type Judgment
struct TypeJudgmentSection: View {
    let analysis: SleepAnalysis
    var total: Int { analysis.osaCount + analysis.csaCount + analysis.uncertainCount }
    var osaP: Double { total > 0 ? Double(analysis.osaCount)       / Double(total) * 100 : 0 }
    var csaP: Double { total > 0 ? Double(analysis.csaCount)       / Double(total) * 100 : 0 }
    var uncP: Double { total > 0 ? Double(analysis.uncertainCount) / Double(total) * 100 : 0 }
    var body: some View {
        SectionCard("3. Type Judgment", color: .purple) {
            HStack {
                typeItem("OSA", osaP, SleepTheme.blue5)
                typeItem("CSA", csaP, SleepTheme.blue6)
                typeItem("Uncertain", uncP, SleepTheme.blue3)
            }
            if total > 0 {
                Chart {
                    SectorMark(angle: .value("OSA", osaP), innerRadius: .ratio(0.5))
                        .foregroundStyle(LinearGradient(colors: [SleepTheme.blue4, SleepTheme.blue5], startPoint: .topLeading, endPoint: .bottomTrailing))
                        .annotation(position: .overlay) { if osaP > 8 { Text("\(Int(osaP))%").font(.caption.bold()).foregroundStyle(.white) } }
                    SectorMark(angle: .value("CSA", max(csaP, 0.01)), innerRadius: .ratio(0.5))
                        .foregroundStyle(LinearGradient(colors: [SleepTheme.blue5, SleepTheme.blue6], startPoint: .topLeading, endPoint: .bottomTrailing))
                        .annotation(position: .overlay) { if csaP > 8 { Text("\(Int(csaP))%").font(.caption.bold()).foregroundStyle(.white) } }
                    SectorMark(angle: .value("Unc", max(uncP, 0.01)), innerRadius: .ratio(0.5))
                        .foregroundStyle(LinearGradient(colors: [SleepTheme.blue2, SleepTheme.blue3], startPoint: .topLeading, endPoint: .bottomTrailing))
                        .annotation(position: .overlay) { if uncP > 8 { Text("\(Int(uncP))%").font(.caption.bold()).foregroundStyle(.white) } }
                }
                .frame(height: 180).chartBackground { _ in Color.clear }
            }
            Text("OSA: chest movement persists during airflow reduction. CSA: both airflow and chest movement are absent.")
                .font(.caption).foregroundStyle(SleepTheme.textSec).fixedSize(horizontal: false, vertical: true)
        }
    }
    func typeItem(_ l: String, _ p: Double, _ c: Color) -> some View {
        VStack(spacing: 4) {
            Text(String(format: "%.0f%%", p)).font(.title3.bold()).foregroundStyle(c)
            Text(l).font(.caption).foregroundStyle(SleepTheme.textMut)
        }
        .frame(maxWidth: .infinity).padding(8)
        .background(c.opacity(0.08)).clipShape(RoundedRectangle(cornerRadius: 8))
        .overlay(RoundedRectangle(cornerRadius: 8).strokeBorder(c.opacity(0.15), lineWidth: 1))
    }
}

// MARK: - Position Impact
struct PositionImpactSection: View {
    let analysis: SleepAnalysis
    var conclusion: String {
        if analysis.supineAHI > analysis.sideAHI + 3 {
            return "Events were more frequent when sleeping on your back. Sleeping on your side may significantly reduce breathing disturbances."
        } else if analysis.supineAHI <= 5 && analysis.sideAHI <= 5 {
            return "Breathing disturbances were minimal in both positions."
        } else {
            return "Position did not significantly affect breathing event frequency."
        }
    }
    var body: some View {
        SectionCard("4. Position Impact", color: .green) {
            HStack(spacing: 12) {
                posCard("bed.double.fill",      "Supine AHI", analysis.supineAHI, analysis.supineHours, "on back")
                posCard("arrow.left.and.right", "Side AHI",   analysis.sideAHI,   analysis.sideHours,   "on side")
            }
            Chart {
                BarMark(x: .value("Position", "Supine"), y: .value("AHI", analysis.supineAHI))
                    .foregroundStyle(LinearGradient(colors: [SleepTheme.blue3, SleepTheme.blue5], startPoint: .bottom, endPoint: .top)).cornerRadius(6)
                BarMark(x: .value("Position", "Side"), y: .value("AHI", analysis.sideAHI))
                    .foregroundStyle(LinearGradient(colors: [SleepTheme.blue4, SleepTheme.blue6], startPoint: .bottom, endPoint: .top)).cornerRadius(6)
                RuleMark(y: .value("Normal", 5))
                    .foregroundStyle(.red.opacity(0.5))
                    .lineStyle(StrokeStyle(lineWidth: 1, dash: [5]))
                    .annotation(position: .top, alignment: .leading) {
                        Text("Normal < 5").font(.caption2).foregroundStyle(.red.opacity(0.7))
                    }
            }
            .frame(height: 140)
            .chartBackground { _ in Color(red: 0.88, green: 0.93, blue: 1.00) }
            .padding(.top, 16).padding(.trailing, 14)
            .background(RoundedRectangle(cornerRadius: 10).fill(Color(red: 0.88, green: 0.93, blue: 1.00)))
            .chartYAxis {
                AxisMarks { v in
                    AxisValueLabel("\(v.as(Double.self).map { Int($0) } ?? 0)").foregroundStyle(SleepTheme.textMut)
                    AxisGridLine().foregroundStyle(SleepTheme.blue3.opacity(0.35))
                }
            }
            Text(conclusion)
                .font(.caption).foregroundStyle(SleepTheme.textSec)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    func posCard(_ icon: String, _ label: String, _ ahi: Double, _ hours: Double, _ sub: String) -> some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .font(.system(size: 26, weight: .semibold))
                .foregroundStyle(SleepTheme.blue5)
            Text(String(format: "%.1f", ahi))
                .font(.system(size: 26, weight: .bold)).foregroundStyle(SleepTheme.blue5)
            Text(label).font(.system(size: 12)).foregroundStyle(SleepTheme.textMut)
            Text(String(format: "%.1f hrs %@", hours, sub))
                .font(.system(size: 11)).foregroundStyle(SleepTheme.textMut)
        }
        .frame(maxWidth: .infinity).padding(14)
        .background(SleepTheme.blue1)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .overlay(RoundedRectangle(cornerRadius: 12).strokeBorder(SleepTheme.blue2, lineWidth: 1))
    }
}

// MARK: - AI Suggestion
struct AISuggestionSection: View {
    let analysis: SleepAnalysis

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("INSIGHTS & SUGGESTIONS")
                .font(.system(size: 12, weight: .semibold)).foregroundStyle(SleepTheme.textMut).kerning(0.8)
            ForEach(analysis.suggestions, id: \.self) { suggestion in
                HStack(alignment: .top, spacing: 12) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 11).fill(SleepTheme.blue2).frame(width: 40, height: 40)
                        Image(systemName: suggestionIcon(for: suggestion))
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundStyle(SleepTheme.blue5)
                    }
                    Text(suggestion.drop(while: { !$0.isLetter && !$0.isNumber }).trimmingCharacters(in: .whitespaces))
                        .font(.system(size: 13)).foregroundStyle(SleepTheme.textPri)
                        .fixedSize(horizontal: false, vertical: true)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    Spacer(minLength: 0)
                }
                .padding(14)
                .background(RoundedRectangle(cornerRadius: 16).fill(.white.opacity(0.82)))
                .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(.white, lineWidth: 1.5))
                .shadow(color: SleepTheme.blue5.opacity(0.06), radius: 8, x: 0, y: 2)
            }
            Text("Suggestions are rule-based and not a substitute for medical advice.")
                .font(.caption2).foregroundStyle(SleepTheme.textMut)
        }
    }

    func suggestionIcon(for suggestion: String) -> String {
        if suggestion.hasPrefix("💡") { return "lightbulb.fill" }
        if suggestion.hasPrefix("⚡") { return "bolt.fill" }
        if suggestion.hasPrefix("🩺") { return "stethoscope" }
        if suggestion.hasPrefix("⚠️") { return "exclamationmark.triangle.fill" }
        if suggestion.hasPrefix("🧠") { return "brain.head.profile" }
        if suggestion.hasPrefix("✅") { return "checkmark.seal.fill" }
        return "moon.zzz.fill"
    }
}
