import Foundation

// MARK: - SensorRecord
struct SensorRecord: Identifiable {
    let id: String
    let heartRate: Double
    let spo2: Double
    let airflow: Double
    let chestMovement: Double
    let breathRate: Double
    let position: String
    let timestamp: Date
    let isAbnormal: Bool
}

// MARK: - Session
struct Session: Identifiable {
    let id: String
    let startTime: Date
    let endTime: Date?
}

// MARK: - Sleep Event
enum SleepEventType: String {
    case apnea = "Apnea"
    case hypopnea = "Hypopnea"
}

enum SleepEventClassification: String {
    case osa = "OSA"
    case csa = "CSA"
    case uncertain = "Uncertain"
}

struct SleepEvent: Identifiable {
    let id = UUID()
    let type: SleepEventType
    let classification: SleepEventClassification
    let startTime: Date
    let endTime: Date
    let duration: TimeInterval
    let minSpo2Time: Date
    let minSpo2: Double
    let spo2Drop: Double
    let position: String
}

// MARK: - Sleep Analysis Result
struct SleepAnalysis {
    let events: [SleepEvent]
    let totalHours: Double
    let ahi: Double
    let ahiClassification: String
    let summary: String
    let totalApnea: Int
    let totalHypopnea: Int
    let longestEventSeconds: Double
    let avgSpo2: Double
    let avgSpo2DropDuringEvents: Double
    let avgHeartRate: Double
    let avgHRSpikeDuringEvents: Double
    let osaCount: Int
    let csaCount: Int
    let uncertainCount: Int
    let supineAHI: Double
    let sideAHI: Double
    let supineHours: Double
    let sideHours: Double
    let suggestions: [String]
}
