import Foundation
import Combine

class SleepRecordingViewModel: ObservableObject {
    private let airflowThresholds: RecordingAirflowThresholds
    
    @Published var isRecording = false
    @Published var elapsedSeconds = 0
    @Published var realtimeRecords: [SensorRecord] = []  // 实时累积
    @Published var lastHR: Double = 0
    @Published var lastSpO2: Double = 0
    @Published var lastAirflow: Double = 0
    @Published var lastAirflowState: String = "No breath"
    
    let ble: BLEManager
    private var timer: Timer?
    private var cancellables = Set<AnyCancellable>()
    
    init(ble: BLEManager, airflowThresholds: RecordingAirflowThresholds = .default) {
        self.ble = ble
        self.airflowThresholds = airflowThresholds
        // 监听BLE数据 → 解析 → 追加到realtimeRecords
        ble.$lastReceivedValue
            .sink { [weak self] value in
                self?.parseAndAppend(value)
            }
            .store(in: &cancellables)
    }
    
    func startRecording() {
        realtimeRecords = []
        elapsedSeconds = 0
        lastHR = 0
        lastSpO2 = 0
        lastAirflow = 0
        lastAirflowState = "No breath"
        isRecording = true
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            self.elapsedSeconds += 1
        }
    }
    
    func stopRecording() -> [SensorRecord] {
        isRecording = false
        timer?.invalidate()
        return realtimeRecords
    }
    
    private func parseAndAppend(_ raw: String) {
        // 解析 "HR:72 SpO2:98 RR:14.5 Air:0.12 Chest:0.08"
        guard isRecording else { return }
        guard let hr = extract("HR:", from: raw),
              let spo2 = extract("SpO2:", from: raw) else { return }
        let rr   = extract("RR:",  from: raw) ?? 14.0
        let airflow = extract("Air:", from: raw) ?? extract("Amp:", from: raw) ?? 0.0
        let chestMovement = extract("Chest:", from: raw) ?? airflow
        lastHR   = hr
        lastSpO2 = spo2
        lastAirflow = airflow
        lastAirflowState = airflowState(for: airflow)
        realtimeRecords.append(SensorRecord(
            id: UUID().uuidString, heartRate: hr, spo2: spo2,
            airflow: airflow, chestMovement: chestMovement, breathRate: rr,
            position: "supine", timestamp: Date(),
            isAbnormal: hr > 100 || hr < 50
        ))
    }
    
    private func airflowState(for airflow: Double) -> String {
        airflowThresholds.state(for: airflow)
    }
    
    private func extract(_ key: String, from str: String) -> Double? {
        guard let range = str.range(of: key) else { return nil }
        let after = str[range.upperBound...]
        return Double(String(after.prefix(while: { $0.isNumber || $0 == "." })))
    }
}
