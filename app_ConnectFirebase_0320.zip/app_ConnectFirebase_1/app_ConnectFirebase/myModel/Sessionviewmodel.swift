import Foundation
import FirebaseFirestore
import Combine

class SessionViewModel: ObservableObject {

    // MARK: - 录制状态
    @Published var isRecording: Bool = false
    @Published var statusMessage: String = "未录制"
    @Published var currentSessionId: String? = nil

    // MARK: - 实时数据
    @Published var latestHeartRate:     Double = 0
    @Published var latestSpo2:          Double = 0
    @Published var latestBreathRate:    Double = 0
    @Published var latestBreathDepth:   Double = 0
    @Published var latestTemperature:   Double = 0
    @Published var latestChestMovement: Double = 0
    @Published var latestBreathingPhase: String = "Idle"
    @Published var latestPosition:      String = "--"

    // MARK: - 历史数据
    @Published var sessions:            [Session]      = []
    @Published var records:             [SensorRecord] = []
    @Published var rawAbnormalRecords:  [SensorRecord] = []
    @Published var selectedSessionId:   String? = nil

    private let db = Firestore.firestore()
    private var listener: ListenerRegistration? = nil
    
    private func resetRealtimeValues() {
        latestHeartRate = 0
        latestSpo2 = 0
        latestBreathRate = 0
        latestBreathDepth = 0
        latestTemperature = 0
        latestChestMovement = 0
        latestBreathingPhase = "Idle"
        latestPosition = "--"
    }

    // MARK: - 开始录制
    func startRecording() {
        resetRealtimeValues()
        let docRef = db.collection("sessions").document()
        let sessionId = docRef.documentID
        let data: [String: Any] = [
            "startTime": Timestamp(date: Date()),
            "endTime": NSNull()
        ]
        docRef.setData(data) { [weak self] error in
            guard let self = self else { return }
            if let error = error {
                DispatchQueue.main.async {
                    self.statusMessage = "创建失败: \(error.localizedDescription)"
                }
                return
            }
            DispatchQueue.main.async {
                self.currentSessionId = sessionId
                self.isRecording = true
                self.statusMessage = "录制中..."
            }
        }
    }

    // MARK: - 停止录制
    func stopRecording() {
        guard let sid = currentSessionId else { return }
        db.collection("sessions").document(sid).updateData([
            "endTime": Timestamp(date: Date())
        ])
        isRecording = false
        statusMessage = "录制完成"
        currentSessionId = nil
    }

    // MARK: - 发送数据
    func sendData(heartRate: Double, spo2: Double, breathRate: Double,
                  breathDepth: Double, temperature: Double) {
        guard let sid = currentSessionId else { return }
        let data: [String: Any] = [
            "timestamp":     Timestamp(date: Date()),
            "heartRate":     heartRate,
            "spo2":          spo2,
            "breathRate":    breathRate,
            "breathDepth":   breathDepth,
            "temperature":   temperature,
            "chestMovement": 0.0,
            "phase":         "Idle",
            "position":      "--"
        ]
        db.collection("sessions").document(sid)
            .collection("records").addDocument(data: data)

        DispatchQueue.main.async {
            self.latestHeartRate   = heartRate
            self.latestSpo2        = spo2
            self.latestBreathRate  = breathRate
            self.latestBreathDepth = breathDepth
            self.latestTemperature = temperature
        }
    }
    
    func ingestBLEPayload(_ raw: String) {
        guard isRecording, currentSessionId != nil else { return }
        guard raw.contains("HR:"), raw.contains("SpO2:") else { return }
        
        let heartRate = extract("HR:", from: raw) ?? 0
        let spo2 = extract("SpO2:", from: raw) ?? 0
        let breathRate = extract("RR:", from: raw) ?? 0
        let breathDepth = extract("Air:", from: raw) ?? 0
        let chestMovement = extract("Chest:", from: raw) ?? 0
        let phase = extractToken("Phase:", from: raw) ?? "Idle"
        let position = extractText("Pos:", from: raw) ?? "--"
        
        guard let sid = currentSessionId else { return }
        let data: [String: Any] = [
            "timestamp": Timestamp(date: Date()),
            "heartRate": heartRate,
            "spo2": spo2,
            "breathRate": breathRate,
            "breathDepth": breathDepth,
            "temperature": 0.0,
            "chestMovement": chestMovement,
            "phase": phase,
            "position": position
        ]
        
        db.collection("sessions").document(sid)
            .collection("records").addDocument(data: data)
        
        DispatchQueue.main.async {
            self.latestHeartRate = heartRate
            self.latestSpo2 = spo2
            self.latestBreathRate = breathRate
            self.latestBreathDepth = breathDepth
            self.latestTemperature = 0.0
            self.latestChestMovement = chestMovement
            self.latestBreathingPhase = phase
            self.latestPosition = position
        }
    }

    // MARK: - 实时监听
    func startRealtimeListening(for sessionId: String) {
        listener = db.collection("sessions").document(sessionId)
            .collection("records")
            .order(by: "timestamp", descending: true)
            .limit(to: 1)
            .addSnapshotListener { [weak self] snapshot, _ in
                guard let self = self,
                      let doc = snapshot?.documents.first else { return }
                let d = doc.data()
                DispatchQueue.main.async {
                    self.latestHeartRate     = d["heartRate"]     as? Double ?? 0
                    self.latestSpo2          = d["spo2"]          as? Double ?? 0
                    self.latestBreathRate    = d["breathRate"]    as? Double ?? 0
                    self.latestBreathDepth   = d["breathDepth"]   as? Double ?? 0
                    self.latestTemperature   = d["temperature"]   as? Double ?? 0
                    self.latestChestMovement = d["chestMovement"] as? Double ?? 0
                    self.latestBreathingPhase = d["phase"] as? String ?? "Idle"
                    self.latestPosition      = d["position"]      as? String ?? "--"
                }
            }
    }

    func stopRealtimeListening() {
        listener?.remove()
        listener = nil
    }

    // MARK: - 获取历史 Sessions
    func fetchSessions(completion: @escaping ([Session]) -> Void) {
        db.collection("sessions")
            .order(by: "startTime", descending: true)
            .getDocuments { [weak self] snapshot, _ in
                guard let self = self else { return }
                let result = snapshot?.documents.compactMap { doc -> Session? in
                    let d = doc.data()
                    guard let start = (d["startTime"] as? Timestamp)?.dateValue() else { return nil }
                    let end = (d["endTime"] as? Timestamp)?.dateValue()
                    return Session(id: doc.documentID, startTime: start, endTime: end)
                } ?? []
                DispatchQueue.main.async {
                    self.sessions = result
                    completion(result)
                }
            }
    }

    // MARK: - 获取某次 Session 的 Records
    func fetchRecords(for sessionId: String) {
        selectedSessionId = sessionId
        db.collection("sessions").document(sessionId)
            .collection("records")
            .order(by: "timestamp")
            .getDocuments { [weak self] snapshot, _ in
                guard let self = self else { return }
                let result = snapshot?.documents.compactMap { doc -> SensorRecord? in
                    let d = doc.data()
                    guard let ts = (d["timestamp"] as? Timestamp)?.dateValue() else { return nil }
                    return SensorRecord(
                        id:            doc.documentID,
                        heartRate:     d["heartRate"]     as? Double ?? 0,
                        spo2:          d["spo2"]          as? Double ?? 0,
                        airflow:       d["breathDepth"]   as? Double ?? 0,
                        chestMovement: d["chestMovement"] as? Double ?? 0,
                        breathRate:    d["breathRate"]    as? Double ?? 0,
                        position:      d["position"]      as? String ?? "--",
                        timestamp:     ts,
                        isAbnormal:    (d["heartRate"] as? Double ?? 0) > 100
                    )
                } ?? []
                DispatchQueue.main.async {
                    self.records = result
                    self.rawAbnormalRecords = result.filter { $0.isAbnormal }
                }
            }
    }
    
    private func extract(_ key: String, from str: String) -> Double? {
        guard let range = str.range(of: key) else { return nil }
        let after = str[range.upperBound...]
        return Double(String(after.prefix(while: { $0.isNumber || $0 == "." })))
    }
    
    private func extractText(_ key: String, from str: String) -> String? {
        guard let range = str.range(of: key) else { return nil }
        let after = str[range.upperBound...]
        return String(after).trimmingCharacters(in: .whitespacesAndNewlines)
    }
    
    private func extractToken(_ key: String, from str: String) -> String? {
        guard let range = str.range(of: key) else { return nil }
        let after = str[range.upperBound...]
        let token = String(after.prefix(while: { !$0.isWhitespace }))
        return token.isEmpty ? nil : token
    }
}
