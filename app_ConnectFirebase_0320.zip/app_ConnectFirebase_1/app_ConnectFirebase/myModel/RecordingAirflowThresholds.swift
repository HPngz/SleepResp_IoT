import Foundation

struct RecordingAirflowThresholds {
    let noBreathThreshold: Double
    let reducedBreathingThreshold: Double
    
    static let `default` = RecordingAirflowThresholds(
        noBreathThreshold: 0.10,
        reducedBreathingThreshold: 0.20
    )
    
    func state(for airflow: Double) -> String {
        if airflow < noBreathThreshold { return "No breath" }
        if airflow <= reducedBreathingThreshold { return "Hypopnea" }
        return "Normal"
    }
}
