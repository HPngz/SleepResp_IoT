import SwiftUI

// MARK: - 录制结束后的报告页（无 Daily/History 切换，有退出按钮）
struct PostSleepReportView: View {
    let sessionId: String
    let onClose: () -> Void
    @StateObject private var vm = SleepReportViewModel()
    @State private var reportTab = 0
    @State private var showStickyHeader = false
    @State private var didLoad = false

    var body: some View {
        SleepPageBackground {
            GeometryReader { proxy in
                ZStack(alignment: .top) {
                    ScrollView {
                        VStack(spacing: 14) {
                            reportHeader
                                .background(
                                    GeometryReader { geo in
                                        let globalMaxY = geo.frame(in: .global).maxY
                                        Color.clear
                                            .onAppear {
                                                showStickyHeader = globalMaxY < 60
                                            }
                                            .onChange(of: globalMaxY) { _, newY in
                                                withAnimation(.easeInOut(duration: 0.2)) {
                                                    showStickyHeader = newY < 60
                                                }
                                            }
                                    }
                                )

                            if vm.isUploading {
                                VStack(spacing: 12) {
                                    ProgressView().tint(SleepTheme.blue5)
                                    Text("Analyzing...").font(.subheadline).foregroundStyle(SleepTheme.textSec)
                                }
                                .frame(maxWidth: .infinity).padding(.vertical, 60)

                            } else if let analysis = vm.sleepAnalysis {

                                AHIHeroCard(analysis: analysis)
                                ReportTabSelector(selected: $reportTab)

                                ZStack(alignment: .top) {
                                    VStack(spacing: 14) {
                                        SummarySection(analysis: analysis, records: vm.chartRecords)
                                        AISuggestionSection(analysis: analysis)
                                    }
                                    .opacity(reportTab == 0 ? 1 : 0)
                                    .allowsHitTesting(reportTab == 0)
                                    .frame(maxHeight: reportTab == 0 ? .infinity : 0)
                                    .animation(.easeInOut(duration: 0.2), value: reportTab)
                                    .clipped()

                                    CoreEventSection(
                                        analysis: analysis,
                                        records: vm.chartRecords,
                                        rawRecords: vm.rawRecords,
                                        hrPeaks: vm.hrPeaks,
                                        spo2Valleys: vm.spo2Valleys,
                                        hrAllMin: vm.hrAllMin,
                                        hrAllMax: vm.hrAllMax,
                                        spo2AllMin: vm.spo2AllMin,
                                        spo2AllMax: vm.spo2AllMax
                                    )
                                    .opacity(reportTab == 1 ? 1 : 0)
                                    .allowsHitTesting(reportTab == 1)
                                    .frame(maxHeight: reportTab == 1 ? .infinity : 0)
                                    .animation(.easeInOut(duration: 0.2), value: reportTab)
                                    .clipped()

                                    VStack(spacing: 14) {
                                        TypeJudgmentSection(analysis: analysis)
                                        PositionImpactSection(analysis: analysis)
                                    }
                                    .opacity(reportTab == 2 ? 1 : 0)
                                    .allowsHitTesting(reportTab == 2)
                                    .frame(maxHeight: reportTab == 2 ? .infinity : 0)
                                    .animation(.easeInOut(duration: 0.2), value: reportTab)
                                    .clipped()
                                }

                            } else {
                                VStack(spacing: 8) {
                                    Image(systemName: "moon.zzz.fill")
                                        .font(.system(size: 40)).foregroundStyle(SleepTheme.blue3)
                                    Text("No data available")
                                        .foregroundStyle(SleepTheme.textSec)
                                }
                                .frame(maxWidth: .infinity).padding(.vertical, 60)
                            }
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 40)

                    if showStickyHeader {
                        collapsedHeaderBar(topInset: proxy.safeAreaInsets.top)
                            .transition(.move(edge: .top).combined(with: .opacity))
                    }
                }
                .animation(.easeInOut(duration: 0.2), value: showStickyHeader)
            }
        }
        .navigationBarHidden(true)
        .toolbar(.hidden, for: .navigationBar)
        .onAppear {
            guard !didLoad else { return }
            didLoad = true
            vm.loadFromFirestore(sessionId: sessionId)
        }
    }

    var reportHeader: some View {
        HStack(alignment: .center) {
            VStack(alignment: .leading, spacing: 2) {
                Text("Sleep Report")
                    .font(.system(size: 30, weight: .bold))
                    .foregroundStyle(SleepTheme.textPri)
                Text("Tonight's Session")
                    .font(.system(size: 14))
                    .foregroundStyle(SleepTheme.textSec)
            }
            Spacer()
            Button {
                onClose()
            } label: {
                ZStack {
                    RoundedRectangle(cornerRadius: 14)
                        .fill(.white.opacity(0.82))
                        .frame(width: 48, height: 48)
                        .overlay(RoundedRectangle(cornerRadius: 14).strokeBorder(.white, lineWidth: 1.5))
                    Image(systemName: "xmark")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundStyle(SleepTheme.textPri)
                }
                .shadow(color: SleepTheme.blue5.opacity(0.1), radius: 8, x: 0, y: 3)
            }
            .buttonStyle(.plain)
        }
        .padding(.top, 16)
    }

    func collapsedHeaderBar(topInset: CGFloat) -> some View {
        VStack(spacing: 0) {
            Color.white
                .frame(height: topInset)

            HStack {
                Text("Sleep Report")
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(SleepTheme.textPri)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 12)
            .background(Color.white)
        }
        .background(Color.white)
        .overlay(alignment: .bottom) {
            Divider().opacity(0.25)
        }
        .shadow(color: SleepTheme.blue5.opacity(0.08), radius: 8, x: 0, y: 3)
        .ignoresSafeArea(edges: .top)
    }
}
