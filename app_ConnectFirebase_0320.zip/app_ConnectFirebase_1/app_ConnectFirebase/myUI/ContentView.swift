import SwiftUI
import Charts

// MARK: - 主界面
// onStartSleep：可选回调，有值时 toolbar 月亮图标触发它（用于从导航栏切 tab）
//               无值时退化为原来的 NavigationLink 行为（独立使用时不变）
struct ContentView: View {
    var onStartSleep: (() -> Void)? = nil          // ← 唯一新增参数

    @StateObject private var sessionVM = SessionViewModel()
    @StateObject private var reportVM = SleepReportViewModel()
    @StateObject private var ble = BLEManager()
    @State private var showHistory = false
    @State private var inputHR = ""
    @State private var inputSpo2 = ""
    @State private var inputBR = ""
    @State private var inputBD = ""
    @State private var inputTemp = ""
    @State private var showRecording = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    recordingControlSection
                    if sessionVM.isRecording { latestDataSection }
                    chartSection
                    historySection
                    testInputSection
                }
                .padding()
            }
            .navigationTitle("健康监测")
            .onAppear {
                sessionVM.fetchSessions { _ in
                    if let id = sessionVM.sessions.first?.id {
                        sessionVM.fetchRecords(for: id)
                    }
                }
            }
            .fullScreenCover(isPresented: $showRecording) {
                RecordingView(
                    sessionVM: sessionVM,
                    reportVM: reportVM,
                    ble: ble,
                    isPresented: $showRecording
                )
            }
        }
    }

    // MARK: - 录制控制
    var recordingControlSection: some View {
        VStack(spacing: 12) {
            Text(sessionVM.statusMessage).font(.caption).foregroundStyle(.gray)
            Button {
                sessionVM.isRecording ? sessionVM.stopRecording() : sessionVM.startRecording()
            } label: {
                HStack {
                    Image(systemName: sessionVM.isRecording ? "stop.circle.fill" : "record.circle")
                    Text(sessionVM.isRecording ? "停止录制" : "开始录制").font(.headline)
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(sessionVM.isRecording ? .red : .green)
                .foregroundStyle(.white)
                .clipShape(RoundedRectangle(cornerRadius: 14))
            }
        }
    }

    // MARK: - 最新数据
    var latestDataSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("实时数据").font(.headline)
            HStack {
                dataItem(title: "心率", value: "\(Int(sessionVM.latestHeartRate))", unit: "BPM", color: .red)
                dataItem(title: "血氧", value: "\(Int(sessionVM.latestSpo2))",       unit: "%",   color: .blue)
                dataItem(title: "呼吸", value: "\(Int(sessionVM.latestBreathRate))", unit: "RPM", color: .green)
            }
            HStack {
                dataItem(title: "深度", value: String(format: "%.1f", sessionVM.latestBreathDepth), unit: "°",  color: .orange)
                dataItem(title: "温度", value: String(format: "%.1f", sessionVM.latestTemperature), unit: "°C", color: .purple)
                Spacer()
            }
        }
        .padding()
        .background(.blue.opacity(0.05))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }

    func dataItem(title: String, value: String, unit: String, color: Color) -> some View {
        VStack {
            Text(title).font(.caption).foregroundStyle(.secondary)
            Text(value).font(.title2.bold()).foregroundStyle(color)
            Text(unit).font(.caption2).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
    }

    // MARK: - 折线图
    var chartSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("心率趋势").font(.headline)
                Spacer()
                if !sessionVM.rawAbnormalRecords.isEmpty {
                    Text("⚠️ \(sessionVM.rawAbnormalRecords.count) 个异常").font(.caption).foregroundStyle(.red)
                }
            }
            if sessionVM.records.isEmpty {
                Text("暂无数据").foregroundStyle(.secondary).frame(maxWidth: .infinity).frame(height: 200)
            } else {
                Chart {
                    ForEach(sessionVM.records) { record in
                        LineMark(x: .value("时间", record.timestamp), y: .value("心率", record.heartRate))
                            .foregroundStyle(.red.opacity(0.6))
                            .interpolationMethod(.catmullRom)
                    }
                    ForEach(sessionVM.rawAbnormalRecords) { record in
                        PointMark(x: .value("时间", record.timestamp), y: .value("心率", record.heartRate))
                            .foregroundStyle(.red)
                            .symbolSize(15)
                    }
                }
                .frame(height: 220)
                .chartXAxis {
                    AxisMarks(values: .automatic(desiredCount: 4)) { _ in
                        AxisValueLabel(format: .dateTime.hour().minute())
                        AxisGridLine()
                    }
                }
                .chartYScale(domain: 40...130)
                .chartYAxis {
                    AxisMarks { value in
                        AxisValueLabel("\(value.as(Double.self).map { Int($0) } ?? 0)")
                        AxisGridLine()
                    }
                }
            }
        }
        .padding()
        .background(.red.opacity(0.05))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }

    // MARK: - 可折叠历史列表
    var historySection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Button {
                withAnimation(.easeInOut) { showHistory.toggle() }
            } label: {
                HStack {
                    Text("历史录制").font(.headline).foregroundStyle(.primary)
                    Spacer()
                    Text("\(sessionVM.sessions.count) 条").font(.caption).foregroundStyle(.secondary)
                    Image(systemName: showHistory ? "chevron.up" : "chevron.down")
                        .foregroundStyle(.secondary).font(.caption)
                }
                .padding()
                .background(.gray.opacity(0.1))
                .clipShape(RoundedRectangle(cornerRadius: 10))
            }
            .buttonStyle(.plain)

            if showHistory {
                if sessionVM.sessions.isEmpty {
                    Text("暂无录制").foregroundStyle(.secondary).padding(.horizontal)
                } else {
                    ForEach(sessionVM.sessions) { session in
                        Button {
                            sessionVM.fetchRecords(for: session.id)
                            withAnimation { showHistory = false }
                        } label: {
                            HStack {
                                VStack(alignment: .leading) {
                                    Text(session.startTime.formatted(.dateTime.month().day().hour().minute()))
                                        .font(.subheadline.bold())
                                    if let end = session.endTime {
                                        Text("时长: \(duration(from: session.startTime, to: end))")
                                            .font(.caption).foregroundStyle(.secondary)
                                    } else {
                                        Text("录制中...").font(.caption).foregroundStyle(.green)
                                    }
                                }
                                Spacer()
                                if sessionVM.selectedSessionId == session.id {
                                    Image(systemName: "checkmark.circle.fill").foregroundStyle(.blue)
                                }
                            }
                            .padding()
                            .background(.gray.opacity(0.08))
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }

    // MARK: - 测试输入
    var testInputSection: some View {
        VStack(spacing: 12) {
            Text("测试输入（之后换成蓝牙数据）").font(.caption).foregroundStyle(.secondary)
            Group {
                TextField("心率 (BPM)",    text: $inputHR)
                TextField("血氧 (%)",      text: $inputSpo2)
                TextField("呼吸频率 (RPM)", text: $inputBR)
                TextField("呼吸深度 (°)",   text: $inputBD)
                TextField("温度 (°C)",     text: $inputTemp)
            }
            .textFieldStyle(.roundedBorder)
            .keyboardType(.decimalPad)

            Button("发送数据") {
                guard !inputHR.isEmpty else { return }
                sessionVM.sendData(
                    heartRate:   Double(inputHR)   ?? 0,
                    spo2:        Double(inputSpo2) ?? 0,
                    breathRate:  Double(inputBR)   ?? 0,
                    breathDepth: Double(inputBD)   ?? 0,
                    temperature: Double(inputTemp) ?? 0
                )
            }
            .font(.headline)
            .frame(maxWidth: .infinity)
            .padding()
            .background(.blue)
            .foregroundStyle(.white)
            .clipShape(RoundedRectangle(cornerRadius: 14))
        }
    }

    // MARK: - 工具方法
    func duration(from start: Date, to end: Date) -> String {
        let seconds = Int(end.timeIntervalSince(start))
        let minutes = seconds / 60
        let hours   = minutes / 60
        if hours > 0 { return "\(hours)小时\(minutes % 60)分钟" }
        else         { return "\(minutes)分钟\(seconds % 60)秒" }
    }
}

#Preview {
    ContentView()
}
