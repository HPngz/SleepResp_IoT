import SwiftUI

struct BLEPanelView: View {
    @ObservedObject var ble: BLEManager
    @ObservedObject var sessionVM: SessionViewModel

    var body: some View {
        
        // 传感器数据行
        Group {
            sensorRow(icon: "wind",         label: "Airflow Rate",    value: sessionVM.isRecording ? String(format: "%.1f RPM", sessionVM.latestBreathRate)  : "--")
            sensorRow(icon: "lungs.fill",   label: "Chest Movement",  value: sessionVM.isRecording ? String(format: "%.2f",     sessionVM.latestBreathDepth) : "--")
            sensorRow(icon: "figure.sleep", label: "Position",        value: "--")
        }
        .padding(.bottom, 4)

        Divider()
        
        VStack(spacing: 12) {
            
            if !ble.discoveredDevices.isEmpty {
                ForEach(ble.discoveredDevices) { device in
                    Button {
                        ble.stopScanning()
                        ble.connect(to: device)
                    } label: {
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(device.displayName).font(.subheadline.bold())
                                Text("Signal: \(device.rssi) dBm").font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            if ble.connectedPeripheral?.identifier == device.id {
                                Image(systemName: "checkmark.circle.fill").foregroundStyle(.green)
                            }
                        }
                        .padding(12)
                        .background(SleepTheme.blue1)
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                    }
                    .buttonStyle(.plain)
                }
            }

            if case .connected = ble.connectionState {
                Button { ble.disconnect() } label: {
                    Text("Disconnect")
                        .font(.subheadline).foregroundStyle(.red)
                        .frame(maxWidth: .infinity).padding(10)
                        .background(RoundedRectangle(cornerRadius: 10).fill(.red.opacity(0.1)))
                }
                .buttonStyle(.plain)
            } else {
                Button {
                    ble.isScanning ? ble.stopScanning() : ble.startScanning()
                } label: {
                    HStack {
                        if ble.isScanning { ProgressView().scaleEffect(0.8).tint(SleepTheme.blue5) }
                        Text(ble.isScanning ? "Scanning..." : "Scan for Devices")
                            .font(.subheadline)
                    }
                    .frame(maxWidth: .infinity).padding(10)
                    .background(RoundedRectangle(cornerRadius: 10).fill(SleepTheme.blue1))
                    .foregroundStyle(SleepTheme.blue5)
                }
                .buttonStyle(.plain)
            }
        }
    }
    func sensorRow(icon: String, label: String, value: String) -> some View {
        HStack(spacing: 10) {
            Image(systemName: icon)
                .font(.system(size: 14))
                .foregroundStyle(SleepTheme.blue5)
                .frame(width: 20)
            Text(label)
                .font(.system(size: 13))
                .foregroundStyle(SleepTheme.textSec)
            Spacer()
            Text(value)
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(SleepTheme.textPri)
        }
        .padding(.vertical, 4)
    }
}
