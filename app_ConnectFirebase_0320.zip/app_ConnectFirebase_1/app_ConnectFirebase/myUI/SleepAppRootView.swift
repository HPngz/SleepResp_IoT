import SwiftUI
import SwiftUI
import Firebase          // ← 确保有这行

// MARK: - Shared Theme (public so SleepReportView can access)
enum SleepTheme {
    static let blue1   = Color(red: 0.93, green: 0.96, blue: 1.00)
    static let blue2   = Color(red: 0.87, green: 0.92, blue: 1.00)
    static let blue3   = Color(red: 0.72, green: 0.82, blue: 1.00)
    static let blue4   = Color(red: 0.48, green: 0.67, blue: 1.00)
    static let blue5   = Color(red: 0.23, green: 0.51, blue: 0.96)
    static let blue6   = Color(red: 0.11, green: 0.37, blue: 0.77)
    static let textPri = Color(red: 0.05, green: 0.14, blue: 0.33)
    static let textSec = Color(red: 0.29, green: 0.44, blue: 0.65)
    static let textMut = Color(red: 0.55, green: 0.66, blue: 0.83)
    static let apnea   = Color.red
    static let hypopnea = Color.orange
    static let hrLine  = Color(red: 0.18, green: 0.72, blue: 0.72)
    static let spo2Line = Color(red: 0.23, green: 0.51, blue: 0.96)
}

// MARK: - Shared Background (public alias used by SleepReportView)
struct SleepPageBackground<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.90, green: 0.94, blue: 1.00),
                    Color(red: 0.83, green: 0.90, blue: 1.00),
                    Color(red: 0.76, green: 0.86, blue: 1.00)
                ],
                startPoint: .top, endPoint: .bottom
            )
            .ignoresSafeArea()
            content
        }
    }
}

// MARK: - Root Tab Container
struct SleepAppRootView: View {
    @StateObject private var vm = SleepReportViewModel()
    @StateObject private var ble = BLEManager()
    @State private var selectedTab: AppTab = .device  // 默认进入 Device
    
    enum AppTab { case device, home, history, settings }
    
    var body: some View {
        ZStack(alignment: .bottom) {
            ZStack {
                DevicePlaceholderView(ble: ble)
                    .opacity(selectedTab == .device ? 1 : 0)
                    .allowsHitTesting(selectedTab == .device)
                
                HomePlaceholderView(selectedTab: $selectedTab, reportVM: vm, ble: ble)
                    .opacity(selectedTab == .home ? 1 : 0)
                    .allowsHitTesting(selectedTab == .home)
                
                HistoryNavigationView(vm: vm)
                    .opacity(selectedTab == .history ? 1 : 0)
                    .allowsHitTesting(selectedTab == .history)
                
                SettingsPlaceholderView()
                    .opacity(selectedTab == .settings ? 1 : 0)
                    .allowsHitTesting(selectedTab == .settings)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            
            BottomTabBar(selected: $selectedTab)
        }
        .ignoresSafeArea(edges: .bottom)
        .onAppear { vm.loadLocalCSV() }
    }
    
    // MARK: - Bottom Tab Bar
    struct BottomTabBar: View {
        @Binding var selected: SleepAppRootView.AppTab
        
        var body: some View {
            HStack(spacing: 0) {
                tabItem(icon: "dot.radiowaves.left.and.right", label: "Device", tab: .device)
                tabItem(icon: "house.fill",     label: "Home",     tab: .home)
                tabItem(icon: "clock.fill",     label: "Record",   tab: .history)
                tabItem(icon: "gearshape.fill", label: "Settings", tab: .settings)
            }
            .padding(.top, 12)
            .padding(.bottom, 10)
            .background(
                Rectangle()
                    .fill(Color.white)
                    .ignoresSafeArea(edges: .bottom)
                    .overlay(alignment: .top) {
                        Divider().opacity(0.3)
                    }
                    .shadow(color: SleepTheme.blue5.opacity(0.08), radius: 8, x: 0, y: -2)
            )
        }
        
        @ViewBuilder
        func tabItem(icon: String, label: String, tab: SleepAppRootView.AppTab) -> some View {
            let isActive = selected == tab
            Button {
                withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) { selected = tab }
            } label: {
                VStack(spacing: 4) {
                    ZStack {
                        if isActive {
                            RoundedRectangle(cornerRadius: 10)
                                .fill(SleepTheme.blue5)
                                .frame(width: 44, height: 30)
                        }
                        Image(systemName: icon)
                            .font(.system(size: isActive ? 16 : 20))
                            .foregroundStyle(isActive ? .white : SleepTheme.textMut)
                    }
                    Text(label)
                        .font(.system(size: 10, weight: .medium))
                        .foregroundStyle(isActive ? SleepTheme.blue5 : SleepTheme.textMut)
                }
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(.plain)
        }
    }
    
    // MARK: - Placeholder Views
    struct DevicePlaceholderView: View {
        @ObservedObject var ble: BLEManager

        var isConnected: Bool {
            if case .connected = ble.connectionState { return true }
            return false
        }

        var body: some View {
            SleepPageBackground {
                VStack(spacing: 0) {

                    // ── 顶部栏 ──
                    HStack {
                        Spacer()
                        Text("Bluetooth Device")
                            .font(.system(size: 17, weight: .semibold))
                            .foregroundStyle(SleepTheme.textPri)
                        Spacer()
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 20)
                    .padding(.bottom, 12)
                    .background(Color.white)

                    ScrollView {
                        VStack(spacing: 16) {

                            // ── 连接状态卡片 ──
                            HStack(spacing: 14) {
                                ZStack {
                                    Circle()
                                        .fill(isConnected ? Color.green.opacity(0.15) : SleepTheme.blue1)
                                        .frame(width: 56, height: 56)
                                    if isConnected {
                                        Image(systemName: "dot.radiowaves.left.and.right")
                                            .font(.system(size: 26))
                                            .foregroundStyle(.green)
                                    } else {
                                        ZStack {
                                            Image(systemName: "dot.radiowaves.left.and.right")
                                                .font(.system(size: 26))
                                                .foregroundStyle(SleepTheme.textMut)
                                            Image(systemName: "slash")
                                                .font(.system(size: 20, weight: .bold))
                                                .foregroundStyle(SleepTheme.textMut.opacity(0.9))
                                        }
                                    }
                                }
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(isConnected ? "Connected" : "Not Connected")
                                        .font(.system(size: 16, weight: .semibold))
                                        .foregroundStyle(SleepTheme.textPri)
                                    Text(isConnected
                                         ? (ble.connectedPeripheral?.name ?? "ESP32")
                                         : "No device paired")
                                        .font(.system(size: 13))
                                        .foregroundStyle(SleepTheme.textMut)
                                }
                                Spacer()
                                if isConnected {
                                    Button { ble.disconnect() } label: {
                                        Text("Disconnect")
                                            .font(.system(size: 13, weight: .medium))
                                            .foregroundStyle(.red)
                                            .padding(.horizontal, 12)
                                            .padding(.vertical, 6)
                                            .background(RoundedRectangle(cornerRadius: 10).fill(.red.opacity(0.1)))
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                            .padding(18)
                            .background(RoundedRectangle(cornerRadius: 18).fill(.white.opacity(0.82)))
                            .overlay(RoundedRectangle(cornerRadius: 18).strokeBorder(.white, lineWidth: 1.5))
                            .shadow(color: SleepTheme.blue5.opacity(0.07), radius: 10, x: 0, y: 3)
                            
                            VStack(spacing: 10) {
                                connectionRow(title: "head", status: ble.headLinkStatus)
                                connectionRow(title: "chest", status: ble.chestLinkStatus)
                            }
                            .padding(16)
                            .background(RoundedRectangle(cornerRadius: 18).fill(.white.opacity(0.82)))
                            .overlay(RoundedRectangle(cornerRadius: 18).strokeBorder(.white, lineWidth: 1.5))
                            .shadow(color: SleepTheme.blue5.opacity(0.07), radius: 10, x: 0, y: 3)

                            // ── 扫描按钮 ──
                            Button {
                                ble.isScanning ? ble.stopScanning() : ble.startScanning()
                            } label: {
                                HStack(spacing: 10) {
                                    if ble.isScanning {
                                        ProgressView().scaleEffect(0.85).tint(.white)
                                    } else {
                                        Image(systemName: "antenna.radiowaves.left.and.right")
                                            .font(.system(size: 16))
                                    }
                                    Text(ble.isScanning ? "Scanning..." : "Scan for Devices")
                                        .font(.system(size: 16, weight: .semibold))
                                }
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 16)
                                .background(
                                    ble.isScanning
                                    ? LinearGradient(colors: [SleepTheme.blue3, SleepTheme.blue4], startPoint: .leading, endPoint: .trailing)
                                    : LinearGradient(colors: [SleepTheme.blue4, SleepTheme.blue5], startPoint: .leading, endPoint: .trailing)
                                )
                                .foregroundStyle(.white)
                                .clipShape(RoundedRectangle(cornerRadius: 18))
                                .shadow(color: SleepTheme.blue5.opacity(0.3), radius: 10, x: 0, y: 5)
                            }
                            .buttonStyle(.plain)

                            // ── 搜索结果 ──
                            if !ble.discoveredDevices.isEmpty {
                                VStack(alignment: .leading, spacing: 10) {
                                    Text("Available Devices")
                                        .font(.system(size: 13, weight: .semibold))
                                        .foregroundStyle(SleepTheme.textMut)
                                        .padding(.horizontal, 4)

                                    ForEach(ble.discoveredDevices) { device in
                                        Button {
                                            ble.stopScanning()
                                            ble.connect(to: device)
                                        } label: {
                                            HStack(spacing: 14) {
                                                ZStack {
                                                    Circle()
                                                        .fill(SleepTheme.blue1)
                                                        .frame(width: 44, height: 44)
                                                    Image(systemName: "dot.radiowaves.left.and.right")
                                                        .font(.system(size: 18))
                                                        .foregroundStyle(SleepTheme.blue5)
                                                }
                                                VStack(alignment: .leading, spacing: 3) {
                                                    Text(device.displayName)
                                                        .font(.system(size: 15, weight: .semibold))
                                                        .foregroundStyle(SleepTheme.textPri)
                                                    Text("Signal: \(device.rssi) dBm")
                                                        .font(.system(size: 12))
                                                        .foregroundStyle(SleepTheme.textMut)
                                                }
                                                Spacer()
                                                if ble.connectedPeripheral?.identifier == device.id {
                                                    Image(systemName: "checkmark.circle.fill")
                                                        .foregroundStyle(.green)
                                                } else {
                                                    Text("Connect")
                                                        .font(.system(size: 13, weight: .medium))
                                                        .foregroundStyle(SleepTheme.blue5)
                                                        .padding(.horizontal, 12)
                                                        .padding(.vertical, 6)
                                                        .background(RoundedRectangle(cornerRadius: 10).fill(SleepTheme.blue1))
                                                }
                                            }
                                            .padding(14)
                                            .background(RoundedRectangle(cornerRadius: 16).fill(.white.opacity(0.82)))
                                            .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(.white, lineWidth: 1.5))
                                            .shadow(color: SleepTheme.blue5.opacity(0.06), radius: 8, x: 0, y: 2)
                                        }
                                        .buttonStyle(.plain)
                                    }
                                }
                            } else if ble.isScanning {
                                VStack(spacing: 12) {
                                    ProgressView()
                                        .scaleEffect(1.2)
                                        .tint(SleepTheme.blue5)
                                    Text("Looking for nearby devices...")
                                        .font(.system(size: 14))
                                        .foregroundStyle(SleepTheme.textMut)
                                }
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 40)
                            }
                        }
                        .padding(.horizontal, 20)
                        .padding(.top, 20)
                        .padding(.bottom, 40)
                    }
                }
            }
        }
        
        private func connectionRow(title: String, status: String) -> some View {
            HStack {
                Text(title)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(SleepTheme.textPri)
                Spacer()
                Text(status.replacingOccurrences(of: "\(title): ", with: ""))
                    .font(.system(size: 13))
                    .foregroundStyle(
                        status.contains("not connected")
                        ? SleepTheme.textMut
                        : (status.contains("waiting") ? .orange : .green)
                    )
            }
        }
    }
    
    struct HomePlaceholderView: View {
        @Binding var selectedTab: SleepAppRootView.AppTab
        @ObservedObject var reportVM: SleepReportViewModel
        @ObservedObject var ble: BLEManager
        @StateObject private var sessionVM = SessionViewModel()
        @State private var showRecording   = false
        
        var body: some View {
            SleepPageBackground {
                VStack(spacing: 0) {
                    
                    // ── 顶部问候 ──
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Good Evening")
                            .font(.system(size: 28, weight: .bold))
                            .foregroundStyle(SleepTheme.textPri)
                        Text("Your sleep quality this week")
                            .font(.system(size: 14))
                            .foregroundStyle(SleepTheme.textMut)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 24)
                    .padding(.top, 24)
                    
                    // ── 睡眠质量描述卡片 ──
                    VStack(alignment: .leading, spacing: 14) {
                        HStack(alignment: .top) {
                            VStack(alignment: .leading, spacing: 8) {
                                HStack(spacing: 8) {
                                    Image(systemName: "chart.line.uptrend.xyaxis")
                                        .font(.system(size: 16, weight: .semibold))
                                        .foregroundStyle(SleepTheme.blue5)
                                    Text("Weekly Summary")
                                        .font(.system(size: 15, weight: .bold))
                                        .foregroundStyle(SleepTheme.textPri)
                                }
                                
                                Text("Your sleep trend looks steadier this week.")
                                    .font(.system(size: 20, weight: .bold))
                                    .foregroundStyle(SleepTheme.textPri)
                                    .lineLimit(2)
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                            .layoutPriority(1)
                            
                            Spacer()
                            
                            Text("-12% events")
                                .font(.system(size: 12, weight: .bold))
                                .foregroundStyle(.white)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(Capsule().fill(SleepTheme.blue5))
                                .fixedSize()
                        }
                        
                        Text("You've slept an average of 6.8 hrs over the past 7 days. Your breathing events have decreased by 12% compared to last week — keep it up.")
                            .font(.system(size: 15))
                            .foregroundStyle(SleepTheme.textSec)
                            .fixedSize(horizontal: false, vertical: true)
                            .lineSpacing(4)
                    }
                    .padding(20)
                    .background(RoundedRectangle(cornerRadius: 18).fill(.white.opacity(0.82)))
                    .overlay(RoundedRectangle(cornerRadius: 18).strokeBorder(.white, lineWidth: 1.5))
                    .shadow(color: SleepTheme.blue5.opacity(0.10), radius: 14, x: 0, y: 4)
                    .padding(.horizontal, 20)
                    .padding(.top, 16)
                    
                    Spacer()
                    
                    // ── 睡眠大图 ──
                    Image("sleeppic")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 240, height: 240)
                        .shadow(color: SleepTheme.blue5.opacity(0.18), radius: 22, x: 0, y: 10)
                        .offset(y: -18)
                        .padding(.bottom, 2)
                    
                    Text("Track your sleep tonight")
                        .font(.custom("Snell Roundhand", size: 28))
                        .foregroundStyle(SleepTheme.textMut)
                        .italic()
                        .padding(.bottom, 28)
                    
                    Spacer()
                    
                    // ── 开始睡眠按钮 ──
                    Button {
                        showRecording = true
                    } label: {
                        HStack(spacing: 10) {
                            Image(systemName: "moon.zzz.fill")
                                .font(.system(size: 18))
                            Text("Start Sleep")
                                .font(.system(size: 17, weight: .semibold))
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 18)
                        .background(
                            LinearGradient(
                                colors: [SleepTheme.blue4, SleepTheme.blue5],
                                startPoint: .leading, endPoint: .trailing
                            )
                        )
                        .foregroundStyle(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 18))
                        .shadow(color: SleepTheme.blue5.opacity(0.35), radius: 12, x: 0, y: 6)
                    }
                    .buttonStyle(.plain)
                    .padding(.horizontal, 24)
                    .padding(.bottom, 110) // 留出 TabBar 空间
                }
            }
            .fullScreenCover(isPresented: $showRecording) {
                RecordingView(
                    sessionVM: sessionVM,
                    reportVM: reportVM,
                    ble: ble,
                    isPresented: $showRecording
                )
            }
        }
    }
    
    struct SettingsPlaceholderView: View {
        var body: some View {
            SleepPageBackground {
                VStack(spacing: 16) {
                    Image(systemName: "gearshape.2.fill")
                        .font(.system(size: 64)).foregroundStyle(SleepTheme.blue4)
                    Text("Settings")
                        .font(.title2.bold()).foregroundStyle(SleepTheme.textPri)
                    Text("App preferences and account settings.")
                        .font(.subheadline).foregroundStyle(SleepTheme.textSec)
                        .multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
    }
    
    // MARK: - History Tab
    struct HistoryNavigationView: View {
        @ObservedObject var vm: SleepReportViewModel
        var body: some View {
            NavigationStack {
                TestChartView(vm: vm)
            }
        }
    }
    

    

}
