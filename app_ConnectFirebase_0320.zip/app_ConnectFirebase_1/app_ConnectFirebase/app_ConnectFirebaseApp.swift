import SwiftUI
import FirebaseCore

@main
struct YourAppNameApp: App {

    init() {
        configureFirebaseIfAvailable()
    }

    var body: some Scene {
        WindowGroup {
            SleepAppRootView()
        }
    }

    private func configureFirebaseIfAvailable() {
        guard FirebaseApp.app() == nil else { return }

        guard let plistPath = Bundle.main.path(forResource: "GoogleService-Info", ofType: "plist") else {
            print("Firebase skipped: GoogleService-Info.plist is not in the app bundle.")
            return
        }

        guard let options = FirebaseOptions(contentsOfFile: plistPath) else {
            print("Firebase skipped: GoogleService-Info.plist could not be parsed.")
            return
        }

        FirebaseApp.configure(options: options)
    }
}
