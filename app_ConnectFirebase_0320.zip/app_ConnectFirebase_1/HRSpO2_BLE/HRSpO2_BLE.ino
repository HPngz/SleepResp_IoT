#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include <BLEClient.h>
#include <BLEScan.h>
#include <BLEAdvertisedDevice.h>
#include <Wire.h>
#include "MAX30105.h"
#include "heartRate.h"

// ── UUID ──
#define MPU_SERVICE_UUID        "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
#define MPU_CHARACTERISTIC_UUID "12345678-1234-1234-1234-123456789abd"
#define MAX_SERVICE_UUID        "aa11bb22-1234-1234-1234-aa11bb22cc33"
#define MAX_CHARACTERISTIC_UUID "bb22cc33-1234-1234-1234-bb22cc33dd44"

// ── 手机BLE服务端 ──
BLEServer* pServer = NULL;
BLECharacteristic* pCharacteristic = NULL;
bool phoneConnected = false;

// ── MPU客户端 ──
BLEClient* pClient = NULL;
BLERemoteCharacteristic* pRemoteChar = NULL;
bool mpuConnected = false;
bool doConnect = false;
bool doScan = true;
BLEAdvertisedDevice* targetDevice = nullptr;
unsigned long lastChestScanAttempt = 0;
unsigned long lastStatusSendTime = 0;

// ── MPU数据 ──
float remoteRR    = 0;
float remoteChest = 0;
float remoteAir   = 0;
String remotePhase = "Idle";
String remotePos  = "Side";

// ── 热敏电阻 Airflow（head本地）──
#define THERMISTOR_PIN 2
#define THERM_INVERT 0
#define THERM_CALIBRATION_MS 3000
#define THERM_FULL_SCALE_DELTA 400.0f
unsigned long thermCalibrationStart = 0;
float thermBaselineSum = 0;
unsigned long thermBaselineCount = 0;
float thermBaseline = 0;
bool thermCalibrated = false;
float localAirflow = 0;

// ── MAX30102 ──
MAX30105 particleSensor;
bool max30102Ready = false;  // 为 false 时跳过心率/血氧，但 BLE 照常工作
long irValue;
int beatAvg = 0;
const byte RATE_SIZE = 4;
byte rates[RATE_SIZE];
byte rateSpot = 0;
long lastBeat = 0;

#define WINDOW 100
long irBuffer[WINDOW];
long redBuffer[WINDOW];
int bufferIndex = 0;

#define SPO2_AVG_SIZE 4
float spo2Buffer[SPO2_AVG_SIZE];
int spo2Spot = 0;
float latestSpo2 = 0;

#define FINGER_THRESHOLD 10000
#define HR_SEND_THRESHOLD 40

// ── 发送计时 ──
unsigned long lastBLESendTime = 0;
unsigned long lastHRSampleTime = 0;   // 心率/血氧固定 10ms 采样，单独 head 时也稳定
#define HR_SAMPLE_MS 10
#define BLE_SEND_INTERVAL 500
#define CHEST_SCAN_INTERVAL 3000
#define CHEST_SCAN_DURATION 2
#define STATUS_SEND_INTERVAL 2000

void notifyPhoneStatus() {
  if (!phoneConnected || pCharacteristic == NULL) return;

  String statusPayload = "STATUS Head:1 Chest:" + String(mpuConnected ? 1 : 0);
  pCharacteristic->setValue(statusPayload.c_str());
  pCharacteristic->notify();
  lastStatusSendTime = millis();
  Serial.print("📤 状态发给手机: "); Serial.println(statusPayload);
}

// ========== MPU通知回调 ==========
void mpuNotifyCallback(BLERemoteCharacteristic* pChar, uint8_t* pData, size_t length, bool isNotify) {
  String value = String((char*)pData).substring(0, length);
  Serial.print("📥 从MPU收到: "); Serial.println(value);

  if (value.indexOf("RR:") >= 0)
    remoteRR = value.substring(value.indexOf("RR:") + 3).toFloat();
  if (value.indexOf("Chest:") >= 0)
    remoteChest = value.substring(value.indexOf("Chest:") + 6).toFloat();
  if (value.indexOf("Air:") >= 0)
    remoteAir = value.substring(value.indexOf("Air:") + 4).toFloat();
  if (value.indexOf("Phase:") >= 0) {
    int phaseStart = value.indexOf("Phase:") + 6;
    int phaseEnd = value.indexOf(" Pos:");
    if (phaseEnd < 0) phaseEnd = value.length();
    remotePhase = value.substring(phaseStart, phaseEnd);
    remotePhase.trim();
  }
  if (value.indexOf("Pos:") >= 0) {
    remotePos = value.substring(value.indexOf("Pos:") + 4);
    remotePos.trim();
  }
}

// ========== 扫描回调 ==========
class MyAdvertisedDeviceCallbacks : public BLEAdvertisedDeviceCallbacks {
  void onResult(BLEAdvertisedDevice advertisedDevice) {
    if (advertisedDevice.getName() == "chest") {
      Serial.println("✅ 找到 chest");
      BLEDevice::getScan()->stop();
      targetDevice = new BLEAdvertisedDevice(advertisedDevice);
      doConnect = true;
    }
  }
};

class MyClientCallbacks : public BLEClientCallbacks {
  void onDisconnect(BLEClient* pClient) {
    mpuConnected = false;
    doConnect = false;
    doScan = true;
    pRemoteChar = NULL;
    targetDevice = nullptr;
    Serial.println("❌ chest 已断开");
    notifyPhoneStatus();
  }
};

// ========== 连接MPU ==========
void connectToMPU() {
  Serial.println("🔗 连接 chest...");
  pClient = BLEDevice::createClient();
  pClient->setClientCallbacks(new MyClientCallbacks());
  pClient->connect(targetDevice);
  delay(1000);

  BLERemoteService* pService = pClient->getService(MPU_SERVICE_UUID);
  if (!pService) {
    Serial.println("❌ 找不到MPU服务");
    pClient->disconnect();
    mpuConnected = false; doConnect = false; doScan = true;
    return;
  }

  pRemoteChar = pService->getCharacteristic(MPU_CHARACTERISTIC_UUID);
  if (!pRemoteChar) {
    Serial.println("❌ 找不到MPU特征");
    pClient->disconnect();
    mpuConnected = false; doConnect = false; doScan = true;
    return;
  }

  if (pRemoteChar->canNotify())
    pRemoteChar->registerForNotify(mpuNotifyCallback);

  mpuConnected = true; doConnect = false; doScan = false;
  Serial.println("✅ chest 连接成功");
  notifyPhoneStatus();
}

// ========== 手机连接回调 ==========
class MyServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer* pServer) {
    phoneConnected = true;
    Serial.println("✅ 手机已连接");
    notifyPhoneStatus();
    if (!mpuConnected) {
      lastChestScanAttempt = 0;
    }
  }
  void onDisconnect(BLEServer* pServer) {
    phoneConnected = false;
    Serial.println("❌ 手机已断开");
    pServer->startAdvertising();
  }
};

void setup() {
  Serial.begin(115200);
  unsigned long serialWaitStart = millis();
  while (!Serial && millis() - serialWaitStart < 3000) {
    delay(10);
  }
  delay(200);
  Serial.println();
  Serial.println("Booting head...");

  Wire.begin(8, 9);
  Wire.setClock(100000);  // 电池供电时 100kHz 比 400kHz 更稳
  analogReadResolution(12);
  pinMode(THERMISTOR_PIN, INPUT);
  thermCalibrationStart = millis();

  // 电池供电时 3.3V 上电较慢，先等一会儿再初始化 MAX30102，失败则再重试一次
  delay(600);
  bool maxOk = particleSensor.begin(Wire);
  if (!maxOk) {
    delay(800);
    maxOk = particleSensor.begin(Wire);
  }
  if (!maxOk) {
    max30102Ready = false;
    Serial.println("WARN: MAX30102 not found. BLE will still work; check wiring/power for HR/SpO2.");
  } else {
    particleSensor.setup();
    particleSensor.setPulseAmplitudeRed(0x2A);
    particleSensor.setPulseAmplitudeIR(0x2A);
    max30102Ready = true;
    Serial.println("✅ MAX30102 ready");
  }

  BLEDevice::init("head");
  pServer = BLEDevice::createServer();
  pServer->setCallbacks(new MyServerCallbacks());

  BLEService* pService = pServer->createService(MAX_SERVICE_UUID);
  pCharacteristic = pService->createCharacteristic(
    MAX_CHARACTERISTIC_UUID,
    BLECharacteristic::PROPERTY_READ |
    BLECharacteristic::PROPERTY_NOTIFY
  );
  pCharacteristic->addDescriptor(new BLE2902());
  pService->start();

  BLEAdvertising* pAdvertising = BLEDevice::getAdvertising();
  pAdvertising->addServiceUUID(MAX_SERVICE_UUID);
  BLEDevice::startAdvertising();
  Serial.println("🔍 手机可以连接了");

  BLEScan* pScan = BLEDevice::getScan();
  pScan->setAdvertisedDeviceCallbacks(new MyAdvertisedDeviceCallbacks());
  pScan->setActiveScan(true);
  Serial.println("📱 等待手机先连接，再扫描 chest...");
}

void loop() {
  if (doConnect) { connectToMPU(); return; }

  if (phoneConnected && millis() - lastStatusSendTime >= STATUS_SEND_INTERVAL) {
    notifyPhoneStatus();
  }

  if (phoneConnected &&
      !mpuConnected &&
      doScan &&
      millis() - lastChestScanAttempt >= CHEST_SCAN_INTERVAL) {
    lastChestScanAttempt = millis();
    Serial.println("🔍 扫描 chest...");
    BLEDevice::getScan()->start(CHEST_SCAN_DURATION, false);
  }

  // ========== 热敏电阻 Airflow（静息基线归一化） ==========
  int thermRaw = analogRead(THERMISTOR_PIN);
  if (!thermCalibrated) {
    thermBaselineSum += thermRaw;
    thermBaselineCount++;
    if (millis() - thermCalibrationStart >= THERM_CALIBRATION_MS && thermBaselineCount > 0) {
      thermBaseline = thermBaselineSum / thermBaselineCount;
      thermCalibrated = true;
      Serial.print("✅ Thermistor baseline: "); Serial.println(thermBaseline);
    }
  }

  float thermDelta = thermCalibrated ? (thermRaw - thermBaseline) : 0.0f;
  float normalizedAir = constrain(fabs(thermDelta) / THERM_FULL_SCALE_DELTA, 0.0f, 1.0f);
  localAirflow = THERM_INVERT ? (1.0f - normalizedAir) : normalizedAir;

  // ========== MAX30102 采样（仅在传感器就绪时） ==========
  // 有手指时只在“每 10ms 一次”里读 getIR/getRed，避免每轮 loop 都读把 FIFO 读空，导致心率算法拿到重复值、波形变平。
  if (max30102Ready) {
    if (irValue < FINGER_THRESHOLD) {
      irValue = particleSensor.getIR();
      long red = particleSensor.getRed();
      if (irValue < FINGER_THRESHOLD) {
        beatAvg = 0; bufferIndex = 0; rateSpot = 0; spo2Spot = 0;
        memset(rates, 0, sizeof(rates));
        memset(spo2Buffer, 0, sizeof(spo2Buffer));
        latestSpo2 = 0;
        lastHRSampleTime = 0;
        delay(50);  // 略降频，仍继续跑热敏与 BLE
      }
    } else {
      // 有手指：固定每 10ms 读一次传感器，这一帧同时给心率和血氧用，不每轮 loop 读
      if (millis() - lastHRSampleTime >= HR_SAMPLE_MS) {
        lastHRSampleTime = millis();
        irValue = particleSensor.getIR();
        long red = particleSensor.getRed();

        if (irValue >= FINGER_THRESHOLD) {
          // 心率
          if (checkForBeat(irValue)) {
            long delta = millis() - lastBeat;
            lastBeat = millis();
            if (delta >= 300) {
              int bpm = (int)(60000.0f / (float)delta);
              if (bpm >= 35 && bpm <= 200) {
                rates[rateSpot++] = (byte)constrain(bpm, 0, 255);
                rateSpot %= RATE_SIZE;
                int sum = 0, n = 0;
                for (byte i = 0; i < RATE_SIZE; i++) {
                  if (rates[i] > 0) { sum += rates[i]; n++; }
                }
                beatAvg = (n > 0) ? (sum / n) : 0;
              }
            }
          }

          // 血氧（用同一帧 IR/Red）
          irBuffer[bufferIndex]  = irValue;
          redBuffer[bufferIndex] = red;
          bufferIndex++;

          if (bufferIndex >= WINDOW) {
            bufferIndex = 0;
            float irDC = 0, redDC = 0;
            long irMax = irBuffer[0], irMin = irBuffer[0];
            long redMax = redBuffer[0], redMin = redBuffer[0];

            for (int i = 0; i < WINDOW; i++) {
              irDC  += irBuffer[i]; redDC += redBuffer[i];
              irMax  = max(irMax,  irBuffer[i]); irMin  = min(irMin,  irBuffer[i]);
              redMax = max(redMax, redBuffer[i]); redMin = min(redMin, redBuffer[i]);
            }
            irDC /= WINDOW; redDC /= WINDOW;

            float irAC  = irMax - irMin;
            float redAC = redMax - redMin;
            float R = (redAC / redDC) / (irAC / irDC);
            float spo2 = constrain(110.0 - 25.0 * R, 70, 100);

            spo2Buffer[spo2Spot++] = spo2;
            spo2Spot %= SPO2_AVG_SIZE;

            float spo2Avg = 0;
            for (int i = 0; i < SPO2_AVG_SIZE; i++) spo2Avg += spo2Buffer[i];
            latestSpo2 = spo2Avg / SPO2_AVG_SIZE;
          }
        }
      }
    }
  } else {
    irValue = 0;
    delay(100);  // 无传感器时降低 loop 频率
  }

  // ========== 串口调试 ==========
  Serial.print("HR:"); Serial.print(beatAvg);
  Serial.print(" SpO2:"); Serial.print((int)latestSpo2);
  Serial.print(" RR:"); Serial.print(remoteRR, 1);
  Serial.print(" Air:"); Serial.print(localAirflow, 3);
  Serial.print(" Chest:"); Serial.print(remoteChest, 3);
  Serial.print(" Phase:"); Serial.print(remotePhase);
  Serial.print(" Pos:"); Serial.println(remotePos);

  // ========== 发送给手机 ==========
  // 只要手机已连接就定时推送（含 HR/SpO2 为 0、无手指时），便于看到 Air/RR/Chest/姿势等
  bool shouldSend = (millis() - lastBLESendTime >= BLE_SEND_INTERVAL && phoneConnected);
  if (shouldSend) {
    lastBLESendTime = millis();
    String payload = "HR:"    + String(beatAvg) +
                     " SpO2:" + String((int)latestSpo2) +
                     " RR:"   + String(remoteRR, 1) +
                     " Air:"  + String(localAirflow, 3) +
                     " Chest:"+ String(remoteChest, 3) +
                     " Phase:"+ remotePhase +
                     " Pos:"  + remotePos;
    pCharacteristic->setValue(payload.c_str());
    pCharacteristic->notify();
    Serial.print("📤 发给手机: "); Serial.println(payload);
  }
}