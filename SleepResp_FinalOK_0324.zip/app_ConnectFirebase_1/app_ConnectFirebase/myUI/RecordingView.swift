import SwiftUI
import FirebaseFirestore

// MARK: - 呼吸圆圈动画
struct BreathingOrb: View {
    let breathRate: Double
    let isConnected: Bool
    let isActive: Bool

    @State private var simPhase: Double = 0
    private let simTimer = Timer.publish(every: 0.05, on: .main, in: .common).autoconnect()
    
    var animationDuration: Double {
        guard isConnected, breathRate > 0 else { return 0.05 }
        let cycleSeconds = 60.0 / breathRate
        return min(max(cycleSeconds / 2.0, 0.6), 4.0)
    }

    var breathingWave: Double {
        return 0.5 - 0.5 * cos(simPhase)
    }
    
    var scale: Double {
        guard isActive else { return 0.72 }
        let baseScale = 0.62
        let expansion = isConnected ? 0.24 : 0.18
        return baseScale + expansion * breathingWave
    }

    var body: some View {
        ZStack {
            Circle()
                .fill(RadialGradient(colors: [SleepTheme.blue4.opacity(0.15), .clear],
                                     center: .center, startRadius: 60, endRadius: 160))
                .frame(width: 320, height: 320)
                .scaleEffect(scale * 1.15)
                .animation(.easeInOut(duration: animationDuration), value: scale)

            Circle()
                .stroke(LinearGradient(colors: [SleepTheme.blue3.opacity(0.5), SleepTheme.blue5.opacity(0.2)],
                                       startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 2)
                .frame(width: 220, height: 220)
                .scaleEffect(scale * 1.08)
                .animation(.easeInOut(duration: animationDuration), value: scale)

            Circle()
                .fill(RadialGradient(colors: [SleepTheme.blue4.opacity(0.85), SleepTheme.blue6.opacity(0.6)],
                                     center: .center, startRadius: 0, endRadius: 100))
                .frame(width: 200, height: 200)
                .scaleEffect(scale)
                .animation(.easeInOut(duration: animationDuration), value: scale)
                .shadow(color: SleepTheme.blue5.opacity(0.4), radius: 30)

            Circle()
                .stroke(.white.opacity(0.25), lineWidth: 1.5)
                .frame(width: 140, height: 140)
                .scaleEffect(scale)
                .animation(.easeInOut(duration: animationDuration), value: scale)
        }
        .onReceive(simTimer) { _ in
            guard isActive else { return }
            let phaseStep: Double
            if isConnected, breathRate > 0 {
                phaseStep = 2.0 * .pi * 0.05 / (60.0 / breathRate)
            } else {
                phaseStep = 0.035
            }
            simPhase += phaseStep
        }
    }
}

// MARK: - 主录制界面
struct RecordingView: View {
    @ObservedObject var sessionVM: SessionViewModel
    @ObservedObject var reportVM: SleepReportViewModel
    @ObservedObject var ble: BLEManager
    @Binding var isPresented: Bool

    @State private var moreExpanded = false
    @State private var showReport   = false
    @State private var finishedSessionId: String? = nil
    @State private var elapsedSec   = 0
    @State private var clockTimer: Timer? = nil
    @State private var showStickyHeader = false

    var isConnected: Bool {
        if case .connected = ble.connectionState { return true }
        return false
    }

    var timeString: String {
        let h = elapsedSec / 3600
        let m = (elapsedSec % 3600) / 60
        let s = elapsedSec % 60
        return String(format: "%02d:%02d:%02d", h, m, s)
    }

    var body: some View {
        SleepPageBackground {
            GeometryReader { proxy in
                ZStack(alignment: .top) {
                    ScrollView {
                        VStack(spacing: 0) {
                            headerRow
                                .padding(.top, 20)
                                .padding(.bottom, 12)
                                .background(
                                    GeometryReader { geo in
                                        let globalMaxY = geo.frame(in: .global).maxY
                                        Color.clear
                                            .onAppear {
                                                showStickyHeader = globalMaxY < 60
                                            }
                                            .onChange(of: globalMaxY) { _, newY in
                                                withAnimation(.easeInOut(duration: 0.2)) {
                                                    showStickyHeader = newY < 60
                                                }
                                            }
                                    }
                                )

                            Spacer().frame(height: 24)

                        // ── 计时器 ──
                        Text(timeString)
                            .font(.system(size: 52, weight: .ultraLight, design: .monospaced))
                            .foregroundStyle(SleepTheme.textPri)
                            .padding(.bottom, 8)

                        // ── 呼吸动画圆圈 ──
                        BreathingOrb(
                            breathRate: sessionVM.latestBreathRate,
                            isConnected: isConnected,
                            isActive: sessionVM.isRecording
                        )
                        .frame(height: 320)

                        // ── HR / SpO₂ 数值 ──
                        HStack(spacing: 32) {
                            vitalBadge(
                                value: sessionVM.isRecording ? String(format: "%.0f", sessionVM.latestHeartRate) : "--",
                                unit: "BPM", icon: "heart.fill", color: .red
                            )
                            vitalBadge(
                                value: sessionVM.isRecording ? String(format: "%.0f", sessionVM.latestSpo2) : "--",
                                unit: "SpO₂ %", icon: "drop.fill", color: SleepTheme.blue5
                            )
                        }
                        .padding(.top, 8)

                        Spacer().frame(height: 24)

                        // ── 更多数据面板 ──
                        VStack(spacing: 0) {
                            Button {
                                withAnimation(.spring(response: 0.3)) { moreExpanded.toggle() }
                            } label: {
                                HStack(spacing: 10) {
                                    Image(systemName: "waveform.path.ecg")
                                        .foregroundStyle(SleepTheme.blue5)
                                    Text("More Data")
                                        .font(.subheadline)
                                        .foregroundStyle(SleepTheme.textPri)
                                    Spacer()
                                    Image(systemName: moreExpanded ? "chevron.up" : "chevron.down")
                                        .font(.caption).foregroundStyle(SleepTheme.textMut)
                                }
                                .padding(16)
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)

                            if moreExpanded {
                                Divider().padding(.horizontal, 16)
                                let breathVal   = sessionVM.isRecording && sessionVM.latestBreathRate > 0 ? String(format: "%.0f", sessionVM.latestBreathRate) : "--"
                                let airflowPercent = sessionVM.latestBreathDepth * 100
                                let airflowVal  = sessionVM.isRecording ? String(format: "%.0f%%", airflowPercent) : "--"
                                let airflowState: String = {
                                    guard sessionVM.isRecording else { return "--" }
                                    if airflowPercent < 10 { return "No breath" }
                                    if airflowPercent <= 30 { return "Breathing" }
                                    return "Strong"
                                }()
                                let airflowColor: Color = {
                                    guard sessionVM.isRecording else { return SleepTheme.blue5 }
                                    if airflowPercent < 10 { return .red }
                                    if airflowPercent <= 30 { return .green }
                                    return SleepTheme.blue5
                                }()
                                let positionVal = sessionVM.isRecording ? sessionVM.latestPosition : "--"
                                let chestVal: String = {
                                    guard sessionVM.isRecording else { return "--" }
                                    let displayChest = min(max(sessionVM.latestChestMovement * 400.0, 0.0), 100.0)
                                    return String(format: "%.0f%%", displayChest)
                                }()

                                HStack(spacing: 0) {
                                    extraDataItem("Breath Rate", value: breathVal,   unit: "/ min",    icon: "lungs.fill",   color: SleepTheme.blue4)
                                    Divider().frame(height: 50).opacity(0.3)
                                    extraDataItem("Airflow",     value: airflowVal,  unit: airflowState, icon: "wind",       color: airflowColor)
                                    Divider().frame(height: 50).opacity(0.3)
                                    extraDataItem("Position", value: positionVal, unit: "", icon: "bed.double.fill", color: .orange)
                                    Divider().frame(height: 50).opacity(0.3)
                                    extraDataItem("Chest",       value: chestVal,    unit: "movement", icon: "waveform",     color: .purple)
                                }
                                .padding(16)
                                .transition(.opacity.combined(with: .move(edge: .top)))
                            }
                        }
                        .background(RoundedRectangle(cornerRadius: 18).fill(.white.opacity(0.82)))
                        .overlay(RoundedRectangle(cornerRadius: 18).strokeBorder(.white, lineWidth: 1.5))
                        .shadow(color: SleepTheme.blue5.opacity(0.07), radius: 10, x: 0, y: 3)
                        .padding(.horizontal, 20)

                        Spacer().frame(height: 12)

                        // 状态 / 错误（此前失败时界面无提示，只看到按钮闪一下）
                        if sessionVM.isStartingSession {
                            Text("Loading")
                                .font(.footnote.weight(.medium))
                                .foregroundStyle(SleepTheme.textSec)
                                .padding(.bottom, 6)
                        } else if sessionVM.statusMessage.contains("失败")
                                    || sessionVM.statusMessage.contains("未初始化")
                                    || sessionVM.statusMessage.contains("未配置") {
                            Text(sessionVM.statusMessage)
                                .font(.footnote)
                                .foregroundStyle(.red)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 16)
                                .padding(.bottom, 8)
                        }

                        // ── 开始/结束按钮 ──
                        Button {
                            if sessionVM.isRecording {
                                finishedSessionId = sessionVM.currentSessionId
                                sessionVM.stopRecording()
                                sessionVM.stopRealtimeListening()
                                clockTimer?.invalidate()
                                clockTimer = nil
                                showReport = true
                            } else {
                                sessionVM.startRecording()
                            }
                        } label: {
                            HStack(spacing: 10) {
                                Image(systemName: sessionVM.isRecording ? "stop.circle.fill" : "moon.zzz.fill")
                                    .font(.title3)
                                Text(sessionVM.isRecording ? "End Sleep & Analyze" : "Start Sleep")
                                    .font(.system(size: 17, weight: .semibold))
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 18)
                            .background(
                                sessionVM.isRecording
                                ? LinearGradient(colors: [.red.opacity(0.85), .red], startPoint: .leading, endPoint: .trailing)
                                : LinearGradient(colors: [SleepTheme.blue4, SleepTheme.blue5], startPoint: .leading, endPoint: .trailing)
                            )
                            .foregroundStyle(.white)
                            .clipShape(RoundedRectangle(cornerRadius: 18))
                            .shadow(color: (sessionVM.isRecording ? Color.red : SleepTheme.blue5).opacity(0.3), radius: 10, x: 0, y: 5)
                        }
                        .buttonStyle(.plain)
                        .disabled(sessionVM.isStartingSession)
                        .opacity(sessionVM.isStartingSession ? 0.6 : 1)
                        .padding(.horizontal, 20)
                        .padding(.bottom, 40)
                        }
                    }

                    if showStickyHeader {
                        collapsedHeaderBar(topInset: proxy.safeAreaInsets.top)
                            .transition(.move(edge: .top).combined(with: .opacity))
                    }
                }
                .animation(.easeInOut(duration: 0.2), value: showStickyHeader)
            }
        }
        .fullScreenCover(isPresented: $showReport) {
            NavigationStack {
                PostSleepReportView(sessionId: finishedSessionId ?? "") {
                    showReport = false
                    finishedSessionId = nil
                    isPresented = false
                }
            }
        }
        .onChange(of: sessionVM.isRecording) { _, recording in
            if recording {
                elapsedSec = 0
                clockTimer?.invalidate()
                let t = Timer(timeInterval: 1, repeats: true) { _ in
                    elapsedSec += 1
                }
                RunLoop.main.add(t, forMode: .common)
                clockTimer = t
            } else {
                clockTimer?.invalidate()
                clockTimer = nil
            }
        }
        .onChange(of: sessionVM.currentSessionId) { _, newId in
            if let id = newId, sessionVM.isRecording {
                sessionVM.startRealtimeListening(for: id)
            }
        }
        .onChange(of: ble.lastReceivedValue) { _, newValue in
            sessionVM.ingestBLEPayload(newValue)
        }
    }

    // MARK: - 辅助视图
    func collapsedHeaderBar(topInset: CGFloat) -> some View {
        VStack(spacing: 0) {
            Color.white
                .frame(height: topInset)

            headerRow
                .padding(.vertical, 12)
                .background(Color.white)
        }
        .background(Color.white)
        .overlay(alignment: .bottom) {
            Divider().opacity(0.25)
        }
        .shadow(color: SleepTheme.blue5.opacity(0.08), radius: 8, x: 0, y: 3)
        .ignoresSafeArea(edges: .top)
    }

    var headerRow: some View {
        HStack {
            Button {
                if sessionVM.isRecording { sessionVM.stopRecording() }
                sessionVM.stopRealtimeListening()
                clockTimer?.invalidate()
                clockTimer = nil
                isPresented = false
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.system(size: 28))
                    .foregroundStyle(SleepTheme.textMut)
            }
            Spacer()
            Text("Sleep Recording")
                .font(.system(size: 17, weight: .semibold))
                .foregroundStyle(SleepTheme.textPri)
            Spacer()
            Image(systemName: "xmark.circle.fill")
                .font(.system(size: 28))
                .foregroundStyle(.clear)
        }
        .padding(.horizontal, 20)
    }

    func extraDataItem(_ label: String, value: String, unit: String, icon: String, color: Color) -> some View {
        VStack(spacing: 4) {
            Image(systemName: icon).font(.system(size: 13)).foregroundStyle(color)
            Text(value).font(.system(size: 22, weight: .bold)).foregroundStyle(SleepTheme.textPri)
            Text(label).font(.system(size: 11)).foregroundStyle(SleepTheme.textMut)
            Text(unit).font(.system(size: 10)).foregroundStyle(SleepTheme.textMut)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 8)
    }

    func vitalBadge(value: String, unit: String, icon: String, color: Color) -> some View {
        VStack(spacing: 4) {
            Image(systemName: icon).font(.system(size: 14)).foregroundStyle(color)
            Text(value)
                .font(.system(size: 38, weight: .bold, design: .rounded))
                .foregroundStyle(SleepTheme.textPri)
                .contentTransition(.numericText())
            Text(unit).font(.system(size: 12)).foregroundStyle(SleepTheme.textMut)
        }
        .frame(minWidth: 100)
        .padding(.vertical, 16).padding(.horizontal, 20)
        .background(RoundedRectangle(cornerRadius: 16).fill(.white.opacity(0.75)))
        .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(.white, lineWidth: 1.5))
        .shadow(color: color.opacity(0.1), radius: 8, x: 0, y: 3)
    }
}
