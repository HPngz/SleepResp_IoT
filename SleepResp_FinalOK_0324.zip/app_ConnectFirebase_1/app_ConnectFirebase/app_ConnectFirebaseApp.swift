import SwiftUI
import FirebaseCore
import FirebaseAuth

@main
struct YourAppNameApp: App {

    init() {
        configureFirebaseIfAvailable()
    }

    var body: some Scene {
        WindowGroup {
            SleepAppRootView()
        }
    }

    private func configureFirebaseIfAvailable() {
        guard FirebaseApp.app() == nil else { return }

        guard let plistPath = Bundle.main.path(forResource: "GoogleService-Info", ofType: "plist") else {
            print("Firebase skipped: GoogleService-Info.plist is not in the app bundle.")
            return
        }

        guard let options = FirebaseOptions(contentsOfFile: plistPath) else {
            print("Firebase skipped: GoogleService-Info.plist could not be parsed.")
            return
        }

        FirebaseApp.configure(options: options)
        signInAnonymouslyIfNeeded()
    }

    /// 与 Firestore 规则 `request.auth != null` 配合：无账号密码，后台生成匿名 UID。
    private func signInAnonymouslyIfNeeded() {
        if Auth.auth().currentUser != nil { return }
        Auth.auth().signInAnonymously { _, error in
            if let error = error {
                print("Firebase 匿名登录失败: \(error.localizedDescription)")
                return
            }
        }
    }
}
