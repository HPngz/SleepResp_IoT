import SwiftUI
import SwiftUI
import Firebase          // ← 确保有这行


// MARK: - Root Tab Container
struct SleepAppRootView: View {
    @StateObject private var vm = SleepReportViewModel()
    @State private var selectedTab: AppTab = .device  // 默认进入 Device

    enum AppTab { case device, home, history, settings }

    var body: some View {
        ZStack(alignment: .bottom) {
            Group {
                switch selectedTab {
                case .device:   DevicePlaceholderView()
                case .home:     HomePlaceholderView(selectedTab: $selectedTab)
                case .history:  HistoryNavigationView(vm: vm)
                case .settings: SettingsPlaceholderView()
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)

            BottomTabBar(selected: $selectedTab)
        }
        .ignoresSafeArea(edges: .bottom)
    }
}

// MARK: - Bottom Tab Bar
struct BottomTabBar: View {
    @Binding var selected: SleepAppRootView.AppTab

    var body: some View {
        HStack(spacing: 0) {
            tabItem(icon: "wifi",           label: "Device",   tab: .device)
            tabItem(icon: "house.fill",     label: "Home",     tab: .home)
            tabItem(icon: "clock.fill",     label: "History",  tab: .history)
            tabItem(icon: "gearshape.fill", label: "Settings", tab: .settings)
        }
        .padding(.top, 12)
        .padding(.bottom, 28)
        .background(
            Rectangle()
                .fill(.ultraThinMaterial)
                .overlay(alignment: .top) {
                    Divider().opacity(0.3)
                }
        )
    }

    @ViewBuilder
    func tabItem(icon: String, label: String, tab: SleepAppRootView.AppTab) -> some View {
        let isActive = selected == tab
        Button {
            withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) { selected = tab }
        } label: {
            VStack(spacing: 4) {
                ZStack {
                    if isActive {
                        RoundedRectangle(cornerRadius: 10)
                            .fill(SleepTheme.blue5)
                            .frame(width: 44, height: 30)
                    }
                    Image(systemName: icon)
                        .font(.system(size: isActive ? 16 : 20))
                        .foregroundStyle(isActive ? .white : SleepTheme.textMut)
                }
                Text(label)
                    .font(.system(size: 10, weight: .medium))
                    .foregroundStyle(isActive ? SleepTheme.blue5 : SleepTheme.textMut)
            }
            .frame(maxWidth: .infinity)
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Placeholder Views
struct DevicePlaceholderView: View {
    var body: some View {
        SleepPageBackground {
            VStack(spacing: 16) {
                Image(systemName: "wifi.circle.fill")
                    .font(.system(size: 64)).foregroundStyle(SleepTheme.blue4)
                Text("Device Connection")
                    .font(.title2.bold()).foregroundStyle(SleepTheme.textPri)
                Text("Connect your sleep monitoring device here.")
                    .font(.subheadline).foregroundStyle(SleepTheme.textSec)
                    .multilineTextAlignment(.center)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }
}

struct HomePlaceholderView: View {
    @Binding var selectedTab: SleepAppRootView.AppTab

    var body: some View {
        // ContentView 自带 NavigationStack，直接嵌入
        // toolbar 里加"开始睡眠"按钮切换到 History tab
        ContentView(onStartSleep: { selectedTab = .history })
    }
}

struct SettingsPlaceholderView: View {
    var body: some View {
        SleepPageBackground {
            VStack(spacing: 16) {
                Image(systemName: "gearshape.2.fill")
                    .font(.system(size: 64)).foregroundStyle(SleepTheme.blue4)
                Text("Settings")
                    .font(.title2.bold()).foregroundStyle(SleepTheme.textPri)
                Text("App preferences and account settings.")
                    .font(.subheadline).foregroundStyle(SleepTheme.textSec)
                    .multilineTextAlignment(.center)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }
}

// MARK: - History Tab
struct HistoryNavigationView: View {
    @ObservedObject var vm: SleepReportViewModel
    var body: some View {
        NavigationStack {
            TestChartView(vm: vm)
        }
    }
}

// MARK: - Shared Background (public alias used by SleepReportView)
struct SleepPageBackground<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.90, green: 0.94, blue: 1.00),
                    Color(red: 0.83, green: 0.90, blue: 1.00),
                    Color(red: 0.76, green: 0.86, blue: 1.00)
                ],
                startPoint: .top, endPoint: .bottom
            )
            .ignoresSafeArea()
            content
        }
    }
}

// MARK: - Shared Theme (public so SleepReportView can access)
enum SleepTheme {
    static let blue1   = Color(red: 0.93, green: 0.96, blue: 1.00)
    static let blue2   = Color(red: 0.87, green: 0.92, blue: 1.00)
    static let blue3   = Color(red: 0.72, green: 0.82, blue: 1.00)
    static let blue4   = Color(red: 0.48, green: 0.67, blue: 1.00)
    static let blue5   = Color(red: 0.23, green: 0.51, blue: 0.96)
    static let blue6   = Color(red: 0.11, green: 0.37, blue: 0.77)
    static let textPri = Color(red: 0.05, green: 0.14, blue: 0.33)
    static let textSec = Color(red: 0.29, green: 0.44, blue: 0.65)
    static let textMut = Color(red: 0.55, green: 0.66, blue: 0.83)
    static let apnea   = Color.red
    static let hypopnea = Color.orange
    static let hrLine  = Color(red: 0.18, green: 0.72, blue: 0.72)
    static let spo2Line = Color(red: 0.23, green: 0.51, blue: 0.96)
}
