import Foundation
import SwiftUI
import FirebaseFirestore

class SessionViewModel: ObservableObject {

    // MARK: - 录制状态
    @Published var isRecording = false
    @Published var currentSessionId: String? = nil
    @Published var statusMessage = ""

    // MARK: - 实时传感器最新值（用于实时显示页面）
    @Published var latestHeartRate: Double = 0
    @Published var latestSpo2: Double = 0
    @Published var latestBreathRate: Double = 0
    @Published var latestBreathDepth: Double = 0
    @Published var latestTemperature: Double = 0

    // MARK: - 历史 Session 列表
    @Published var sessions: [Session] = []
    @Published var selectedSessionId: String? = nil

    // MARK: - 从 Firebase 读回来的当前 Session 数据
    @Published var records: [SensorRecord] = []           // 降采样，用于图表
    @Published var rawAbnormalRecords: [SensorRecord] = [] // 原始异常点

    private let db = Firestore.firestore()
    private var timer: Timer? = nil

    // MARK: - 开始录制
    func startRecording() {
        let ref = db.collection("sessions").document()
        let sessionId = ref.documentID
        ref.setData(["startTime": Timestamp(date: Date()), "endTime": NSNull()]) { error in
            if let error = error { self.statusMessage = "开始失败: \(error.localizedDescription)"; return }
            self.currentSessionId = sessionId
            self.isRecording = true
            self.records = []
            self.rawAbnormalRecords = []
            self.statusMessage = "录制中..."
            self.fetchSessions()
        }
    }

    // MARK: - 停止录制
    func stopRecording() {
        guard let sessionId = currentSessionId else { return }
        db.collection("sessions").document(sessionId).updateData(["endTime": Timestamp(date: Date())]) { error in
            if let error = error { self.statusMessage = "停止失败: \(error.localizedDescription)"; return }
            self.isRecording = false
            self.statusMessage = "录制完成 ✅"
            self.fetchSessions { _ in
                if let id = self.currentSessionId { self.fetchRecords(for: id) }
            }
        }
        timer?.invalidate()
        timer = nil
    }

    // MARK: - 写入数据
    func sendData(heartRate: Double, spo2: Double, breathRate: Double, breathDepth: Double, temperature: Double) {
        guard let sessionId = currentSessionId, isRecording else {
            statusMessage = "请先开始录制"
            return
        }
        latestHeartRate = heartRate
        latestSpo2 = spo2
        latestBreathRate = breathRate
        latestBreathDepth = breathDepth
        latestTemperature = temperature
        let isAbnormal = heartRate > 100 || heartRate < 50
        db.collection("sessions").document(sessionId).collection("data").addDocument(data: [
            "heartRate": heartRate, "spo2": spo2, "breathRate": breathRate,
            "breathDepth": breathDepth, "temperature": temperature,
            "isAbnormal": isAbnormal, "timestamp": Timestamp(date: Date())
        ]) { error in
            self.statusMessage = error != nil
                ? "写入失败: \(error!.localizedDescription)"
                : (isAbnormal ? "⚠️ 异常数据已记录" : "写入成功 ✅")
        }
    }

    // MARK: - 读取某次 Session 的数据
    func fetchRecords(for sessionId: String) {
        selectedSessionId = sessionId
        db.collection("sessions").document(sessionId).collection("data")
            .order(by: "timestamp", descending: false)
            .getDocuments { snapshot, _ in
                guard let docs = snapshot?.documents else { return }
                let allRecords: [SensorRecord] = docs.compactMap { doc in
                    let d = doc.data()
                    guard let hr = d["heartRate"] as? Double,
                          let ts = d["timestamp"] as? Timestamp,
                          hr > 0 else { return nil }
                    return SensorRecord(
                        id: doc.documentID, heartRate: hr,
                        spo2: d["spo2"] as? Double ?? 97.0,
                        airflow: d["airflow"] as? Double ?? 1.0,
                        chestMovement: d["chestMovement"] as? Double ?? 1.0,
                        breathRate: d["breathRate"] as? Double ?? 14.0,
                        position: d["position"] as? String ?? "supine",
                        timestamp: ts.dateValue(),
                        isAbnormal: d["isAbnormal"] as? Bool ?? (hr > 100 || hr < 50)
                    )
                }
                self.rawAbnormalRecords = allRecords.filter { $0.isAbnormal }
                self.records = self.downsample(allRecords)
                self.statusMessage = "加载 \(allRecords.count) 条 → 显示 \(self.records.count) 点，异常 \(self.rawAbnormalRecords.count) 个"
            }
    }

    // MARK: - 读取所有 Session 列表
    func fetchSessions(completion: ((String?) -> Void)? = nil) {
        db.collection("sessions").order(by: "startTime", descending: true)
            .getDocuments { snapshot, _ in
                guard let docs = snapshot?.documents else { return }
                self.sessions = docs.compactMap { doc in
                    let data = doc.data()
                    guard let start = data["startTime"] as? Timestamp else { return nil }
                    return Session(
                        id: doc.documentID,
                        startTime: start.dateValue(),
                        endTime: (data["endTime"] as? Timestamp)?.dateValue()
                    )
                }
                completion?(self.sessions.first?.id)
            }
    }

    // MARK: - 降采样（按录制时长自动选粒度）
    private func downsample(_ input: [SensorRecord]) -> [SensorRecord] {
        guard input.count > 1,
              let first = input.first?.timestamp,
              let last  = input.last?.timestamp else { return input }
        let duration = last.timeIntervalSince(first)
        let gs: Double
        switch duration {
        case ..<600:       gs = 10
        case 600..<3600:   gs = 60
        case 3600..<21600: gs = 300
        default:           gs = 600
        }
        return downsampleForChart(input, secondsPerPoint: gs)
    }

    // MARK: - 降采样（固定秒数/点）
    func downsampleForChart(_ input: [SensorRecord], secondsPerPoint: Double = 24) -> [SensorRecord] {
        guard input.count > 1,
              let first = input.first?.timestamp else { return input }
        var result: [SensorRecord] = []
        var groupStart = first
        var group: [SensorRecord] = []

        func flush() {
            guard !group.isEmpty else { return }
            let c = Double(group.count)
            result.append(SensorRecord(
                id: UUID().uuidString,
                heartRate:     group.map { $0.heartRate }.reduce(0, +) / c,
                spo2:          group.map { $0.spo2 }.reduce(0, +) / c,
                airflow:       group.map { $0.airflow }.reduce(0, +) / c,
                chestMovement: group.map { $0.chestMovement }.reduce(0, +) / c,
                breathRate:    group.map { $0.breathRate }.reduce(0, +) / c,
                position:      group.last?.position ?? "supine",
                timestamp:     groupStart + secondsPerPoint / 2,
                isAbnormal:    group.contains { $0.isAbnormal }
            ))
        }
        for r in input {
            if r.timestamp < groupStart + secondsPerPoint { group.append(r) }
            else { flush(); groupStart += secondsPerPoint; group = [r] }
        }
        flush()
        return result
    }
}
