import Foundation
import SwiftUI

struct HRPeak: Identifiable {
    let id: UUID
    let time: Date
    let value: Double
    let eventType: SleepEventType
}

struct SpO2Valley: Identifiable {
    let id: UUID
    let time: Date
    let value: Double
    let eventType: SleepEventType
}

class SleepReportViewModel: ObservableObject {

    // MARK: - 状态
    @Published var isUploading = false
    @Published var uploadStatus = ""

    // MARK: - 图表数据
    @Published var chartRecords: [SensorRecord] = []     // 降采样 24s/点，用于画折线
    @Published var rawRecords: [SensorRecord] = []        // 原始数据，用于分析和查峰谷值

    // MARK: - 分析结果
    @Published var sleepAnalysis: SleepAnalysis? = nil
    
    @Published var hrPeaks: [HRPeak] = []
    @Published var spo2Valleys: [SpO2Valley] = []
    @Published var hrAllMin: Double = 0
    @Published var hrAllMax: Double = 0
    @Published var spo2AllMin: Double = 0
    @Published var spo2AllMax: Double = 0

    // MARK: - 从本地 CSV 加载
    func loadLocalCSV() {
        isUploading = true
        uploadStatus = "Analyzing..."

        guard let url = Bundle.main.url(forResource: "sleep_data", withExtension: "csv"),
              let content = try? String(contentsOf: url, encoding: .utf8) else {
            uploadStatus = "❌ File reading failed"
            isUploading = false
            return
        }

        var lines = content.components(separatedBy: "\n").filter { !$0.isEmpty }
        guard lines.count > 1 else {
            uploadStatus = "❌ 文件格式错误"
            isUploading = false
            return
        }
        lines.removeFirst() // 去掉表头
        
        //创建日期格式工具formatter
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss.S"
        
        
        var allRecords: [SensorRecord] = []
        for line in lines {
            let cols = line.components(separatedBy: ",")
            guard cols.count >= 2,
                  let hr = Double(cols[1].trimmingCharacters(in: .whitespaces)) else { continue }
            let date       = formatter.date(from: cols[0].trimmingCharacters(in: .whitespaces)) ?? Date()
            let spo2       = Double(cols.count > 2 ? cols[2].trimmingCharacters(in: .whitespaces) : "") ?? 97.0
            let airflow    = Double(cols.count > 3 ? cols[3].trimmingCharacters(in: .whitespaces) : "") ?? 1.0
            let chestMov   = Double(cols.count > 4 ? cols[4].trimmingCharacters(in: .whitespaces) : "") ?? 1.0
            let breathRate = Double(cols.count > 5 ? cols[5].trimmingCharacters(in: .whitespaces) : "") ?? 14.0
            let position   = cols.count > 6
                ? cols[6].trimmingCharacters(in: .whitespaces).replacingOccurrences(of: "\r", with: "")
                : "supine"
            allRecords.append(SensorRecord(
                id: UUID().uuidString, heartRate: hr, spo2: spo2,
                airflow: airflow, chestMovement: chestMov, breathRate: breathRate,
                position: position, timestamp: date,
                isAbnormal: hr > 100 || hr < 50
            ))
        }
        
        //主线程异步执行
        DispatchQueue.main.async {
            self.rawRecords = allRecords //原始数据
            // 24秒/点 → 8小时约1200点，2小时窗口内约150点。计算数据总时长
            let totalSeconds = allRecords.last!.timestamp.timeIntervalSince(allRecords.first!.timestamp)
            //计算每个点代表多少秒
            let secondsPerPoint = max(0.5, (totalSeconds / 1200.0).rounded())
            //降采样
            self.chartRecords = self.downsampleForChart(allRecords, secondsPerPoint: secondsPerPoint)
            //数据分析算法，输出数据
            self.sleepAnalysis = self.analyzeSleep(records: allRecords)
            
            let analysis = self.sleepAnalysis!
                self.hrAllMin   = allRecords.map { $0.heartRate }.min() ?? (analysis.avgHeartRate - 15)
                self.hrAllMax   = allRecords.map { $0.heartRate }.max() ?? (analysis.avgHeartRate + 15)
                self.spo2AllMin = allRecords.map { $0.spo2 }.min()     ?? (analysis.avgSpo2 - 5)
                self.spo2AllMax = allRecords.map { $0.spo2 }.max()     ?? 100
                self.hrPeaks = analysis.events.compactMap { event in
                    let r = allRecords.filter { $0.timestamp >= event.startTime && $0.timestamp <= event.endTime }
                    guard let p = r.max(by: { $0.heartRate < $1.heartRate }) else { return nil }
                    return HRPeak(id: event.id, time: p.timestamp, value: p.heartRate, eventType: event.type)
                }
                self.spo2Valleys = analysis.events.compactMap { event in
                    let r = allRecords.filter { $0.timestamp >= event.startTime && $0.timestamp <= event.endTime }
                    guard let v = r.min(by: { $0.spo2 < $1.spo2 }) else { return nil }
                    return SpO2Valley(id: event.id, time: v.timestamp, value: v.spo2, eventType: event.type)
                }
            
            //更新状态，已加载xx条数据
            self.uploadStatus = "已加载 \(allRecords.count) 条数据"
            self.isUploading = false
        }
    }

    // MARK: - 降采样（固定秒数/点）
    func downsampleForChart(_ input: [SensorRecord], secondsPerPoint: Double = 24) -> [SensorRecord] {
        //数据《=1条，返回原始数据，防崩溃
        guard input.count > 1,
              let first = input.first?.timestamp else { return input }
        var result: [SensorRecord] = [] //降采样后的数据
        var groupStart = first //group开始时间
        var group: [SensorRecord] = [] //当前group内的数据
        
        //把当前group的数据合并成一个平均点
        func flush() {
            guard !group.isEmpty else { return } //检查空
            let c = Double(group.count) //数据数量计算
            //计算平均值
            result.append(SensorRecord(
                id: UUID().uuidString,
                heartRate:     group.map { $0.heartRate }.reduce(0, +) / c,
                spo2:          group.map { $0.spo2 }.reduce(0, +) / c,
                airflow:       group.map { $0.airflow }.reduce(0, +) / c,
                chestMovement: group.map { $0.chestMovement }.reduce(0, +) / c,
                breathRate:    group.map { $0.breathRate }.reduce(0, +) / c,
                position:      group.last?.position ?? "supine",
                timestamp:     groupStart + secondsPerPoint / 2,
                isAbnormal:    group.contains { $0.isAbnormal }
            ))
        }
        //判断数据在不在当前group。超出了就不计入当前group，计算已加入数据的平均，然后开启新的group
        for r in input {
            if r.timestamp < groupStart + secondsPerPoint { group.append(r) }
            else { flush(); groupStart += secondsPerPoint; group = [r] }
        }
        flush() //如果最后剩下的不足以构成一组，也算一次平均
        return result
    }

    // MARK: - 睡眠分析
    func analyzeSleep(records: [SensorRecord]) -> SleepAnalysis {
        //检查空
        guard !records.isEmpty,
              let firstTime = records.first?.timestamp,
              let lastTime  = records.last?.timestamp else { return emptyAnalysis() }

        //总睡眠小时
        let totalHours = max(lastTime.timeIntervalSince(firstTime) / 3600.0, 0.01)
        let sortedSpo2 = records.map { $0.spo2 }.sorted()
        let p95index = Int(Double(sortedSpo2.count) * 0.95)
        let baselineSpo2 = sortedSpo2[min(p95index, sortedSpo2.count - 1)]
        //呼吸暂停事件列表
        var events: [SleepEvent] = []
        var i = 0

        //遍历数据
        while i < records.count {
            //判断两种呼吸暂停
            let r = records[i]
            let isApnea    = r.airflow < 0.1
            let isHypopnea = r.airflow >= 0.1 && r.airflow < 0.7
            //如果正常，跳到下一条
            guard isApnea || isHypopnea else { i += 1; continue }

            //如果是异常，就一直继续判断。i开始，j结束。
            var j = i + 1
            while j < records.count {
                let next = records[j]
                let still = isApnea ? next.airflow < 0.1 : (next.airflow >= 0.1 && next.airflow < 0.7)
                if still { j += 1 } else { break }
            }
            //取出这段时间的数据
            let eventRecs = Array(records[i..<j])
            //计算持续时间
            let duration  = records[min(j, records.count - 1)].timestamp.timeIntervalSince(r.timestamp)

            //超过10s算暂停
            if duration >= 10 {
                //检查事件+后面一小段时间
                let windowRecs = Array(records[i..<min(j + 10, records.count)])
                //最低血氧
                let minSpo2    = windowRecs.map { $0.spo2 }.min() ?? r.spo2
                //下降最大值
                let spo2Drop   = baselineSpo2 - minSpo2
                //Apnea        → 直接算
                //Hypopnea     → 必须血氧下降 ≥3%
                let qualifies  = isApnea || (isHypopnea && spo2Drop >= 3.0)

                if qualifies {
                    //胸腔运动，判断阻塞型 or 中枢型
                    //avgChest > 0.2 → OSA
                    //avgChest <=0.2 → CSA
                    let avgChest = eventRecs.map { $0.chestMovement }.reduce(0, +) / Double(eventRecs.count)
                    let classification: SleepEventClassification = isApnea
                        ? (avgChest > 0.2 ? .osa : .csa)
                        : .osa
                    //记录事件
                    events.append(SleepEvent(
                        type: isApnea ? .apnea : .hypopnea,
                        classification: classification,
                        startTime: r.timestamp,
                        endTime: records[min(j, records.count - 1)].timestamp,
                        duration: duration,
                        minSpo2: minSpo2,
                        spo2Drop: spo2Drop,
                        position: r.position
                    ))
                }
            }
            //跳到事件结束位置
            i = j
        }

        //统计事件数量
        let totalApnea    = events.filter { $0.type == .apnea }.count
        let totalHypopnea = events.filter { $0.type == .hypopnea }.count
        //计算AHI，判断严重程度
        let ahi           = Double(totalApnea + totalHypopnea) / totalHours
        let ahiClass: String = ahi < 5 ? "Normal" : ahi < 15 ? "Mild" : ahi < 30 ? "Moderate" : "Severe"
        //最长呼吸暂停时长
        let longestEvent  = events.map { $0.duration }.max() ?? 0
        //血氧
        let avgSpo2       = records.map { $0.spo2 }.reduce(0, +) / Double(records.count)
        let avgSpo2Drop   = events.isEmpty ? 0.0 : events.map { $0.spo2Drop }.reduce(0, +) / Double(events.count)
        //心率。拿恢复后30-120s的计算正常平均值，减去异常时候的
        let avgHR         = records.map { $0.heartRate }.reduce(0, +) / Double(records.count)
        var hrSpikes: [Double] = []
        for event in events {
            let during = records.filter { $0.timestamp >= event.startTime && $0.timestamp <= event.endTime }
            let after  = records.filter { $0.timestamp > event.endTime.addingTimeInterval(30) && $0.timestamp <= event.endTime.addingTimeInterval(120) }
            if let maxAfter = after.map({ $0.heartRate }).max(), !during.isEmpty {
                let avgDuring = during.map { $0.heartRate }.reduce(0, +) / Double(during.count)
                hrSpikes.append(maxAfter - avgDuring)
            }
        }
        let avgHRSpike = hrSpikes.isEmpty ? 0 : hrSpikes.reduce(0, +) / Double(hrSpikes.count)

        //OSA/CSA
        let osaCount = events.filter { $0.classification == .osa }.count
        let csaCount = events.filter { $0.classification == .csa }.count
        let uncCount = events.filter { $0.classification == .uncertain }.count

        //睡姿
        let supineH   = Double(records.filter { $0.position == "supine" }.count) / Double(records.count) * totalHours
        let sideH     = Double(records.filter { $0.position == "side"   }.count) / Double(records.count) * totalHours
        let supineAHI = supineH > 0 ? Double(events.filter { $0.position == "supine" }.count) / supineH : 0
        let sideAHI   = sideH   > 0 ? Double(events.filter { $0.position == "side"   }.count) / sideH   : 0

        //总结语句
        let summary: String
        if osaCount > csaCount {
            summary = "Repeated airflow reduction with preserved respiratory effort suggests an obstructive pattern."
        } else if csaCount > 0 {
            summary = "Central apnea events detected with absent chest movement, suggesting central nervous system involvement."
        } else {
            summary = "Breathing patterns appear normal throughout the night."
        }

        var suggestions: [String] = []
        if supineAHI > sideAHI + 3 {
            suggestions.append("💡 Your AHI is significantly higher when lying on your back. Try sleeping on your side.")
        }
        if avgHRSpike > 8 {
            suggestions.append("⚡ Large HR fluctuations during events indicate high autonomic nerve pressure. Consider consulting a specialist.")
        }
        if avgSpo2 < 94 {
            suggestions.append("🩺 Low average SpO₂ detected throughout the night. Further medical evaluation is recommended.")
        }
        if ahi >= 15 {
            suggestions.append("⚠️ Moderate to severe sleep apnea detected. A sleep study and medical consultation are strongly advised.")
        }
        if csaCount > 0 {
            suggestions.append("🧠 Central apnea events were detected, which may relate to heart or neurological conditions. Consult your doctor.")
        }
        if suggestions.isEmpty {
            suggestions.append("✅ Sleep breathing patterns look generally healthy. Maintain consistent sleep habits.")
        }

        return SleepAnalysis(
            events: events, totalHours: totalHours, ahi: ahi,
            ahiClassification: ahiClass, summary: summary,
            totalApnea: totalApnea, totalHypopnea: totalHypopnea,
            longestEventSeconds: longestEvent, avgSpo2: avgSpo2,
            avgSpo2DropDuringEvents: avgSpo2Drop, avgHeartRate: avgHR,
            avgHRSpikeDuringEvents: avgHRSpike, osaCount: osaCount,
            csaCount: csaCount, uncertainCount: uncCount,
            supineAHI: supineAHI, sideAHI: sideAHI,
            supineHours: supineH, sideHours: sideH,
            suggestions: suggestions
        )
    }

    private func emptyAnalysis() -> SleepAnalysis {
        SleepAnalysis(
            events: [], totalHours: 0, ahi: 0, ahiClassification: "N/A", summary: "",
            totalApnea: 0, totalHypopnea: 0, longestEventSeconds: 0,
            avgSpo2: 0, avgSpo2DropDuringEvents: 0, avgHeartRate: 0, avgHRSpikeDuringEvents: 0,
            osaCount: 0, csaCount: 0, uncertainCount: 0,
            supineAHI: 0, sideAHI: 0, supineHours: 0, sideHours: 0,
            suggestions: []
        )
    }
}
